package com.bozdar.chargesach

import android.app.ActivityManager
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.provider.Settings
import android.speech.tts.TextToSpeech
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.util.Locale

/**
 * Charge Sach — Battery Doctor.
 *
 * Ye native hissa sirf Android ke apne BatteryManager se ASAL readings
 * leta hai aur Flutter ko deta hai. Koi reading banayi nahi jati:
 * jo phone ka hardware deta hai, wohi dikhta hai. Jo cheez kisi phone
 * par available nahi hoti, wahan null jata hai aur app saaf likh deti
 * hai ke ye reading is phone par nahi milti.
 *
 * BOLNE WALI KHIDMAT: Android ka apna TextToSpeech engine istemal
 * hota hai. Awaz ke liye pehle Urdu (ur-PK) koshish hoti hai, na mile
 * to Hindi, phir English — jumle Roman Urdu mein hi hote hain, is
 * liye kisi bhi awaz mein samajh aa jate hain. Saare jumle Dart taraf
 * bante hain aur wohi asal nap-tol (voltage/current/percent) par
 * mabni hote hain — bolne mein bhi koi jhoota dawa nahi hota.
 *
 * Charger lagne/nikalne ki khabar ke liye runtime BroadcastReceiver
 * hai (ACTION_POWER_CONNECTED / ACTION_POWER_DISCONNECTED). Ye tab
 * kaam karta hai jab app khuli ho (process zinda ho) — app band ho
 * to awaz nahi aati, aur app ye baat user ko saaf batati hai.
 * Is ke liye koi extra permission nahi chahiye.
 *
 * Brightness sirf tab badalti hai jab user Tez Charge Mode dabaye aur
 * system ki ijazat (WRITE_SETTINGS) pehle se di hui ho. Wi-Fi/Bluetooth
 * app khud band NAHI karti — user ko system settings ki screen khol
 * kar di jati hai, faisla user ka apna hota hai.
 */
class MainActivity : FlutterActivity() {

    private val channelName = "com.bozdar.chargesach/battery"
    private var channel: MethodChannel? = null

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsLangLabel = "tayyar nahi"

    /** Charger lagne/nikalne par Dart ko khabar deta hai. */
    private val powerReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val type = when (intent?.action) {
                Intent.ACTION_POWER_CONNECTED -> "connected"
                Intent.ACTION_POWER_DISCONNECTED -> "disconnected"
                else -> return
            }
            val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            channel?.invokeMethod(
                "onPowerEvent",
                mapOf(
                    "type" to type,
                    "percent" to if (pct == Int.MIN_VALUE) null else pct
                )
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initTts()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(powerReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(powerReceiver, filter)
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(powerReceiver)
        } catch (e: Exception) {
            // pehle se unregister ho to koi baat nahi
        }
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    /** Urdu (ur-PK) pehle, warna Hindi, warna English/default awaz. */
    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsLangLabel = selectTtsLanguage()
                ttsReady = true
            }
        }
    }

    private fun selectTtsLanguage(): String {
        val candidates = listOf(
            Locale("ur", "PK") to "Urdu (Pakistan)",
            Locale("ur") to "Urdu",
            Locale("hi", "IN") to "Hindi",
            Locale.US to "English"
        )
        for ((locale, label) in candidates) {
            val r = tts?.setLanguage(locale)
            if (r != TextToSpeech.LANG_MISSING_DATA &&
                r != TextToSpeech.LANG_NOT_SUPPORTED
            ) {
                return label
            }
        }
        return "default"
    }

    private fun speak(text: String): Boolean {
        if (!ttsReady) return false
        val id = System.currentTimeMillis().toString()
        val r = tts?.speak(text, TextToSpeech.QUEUE_ADD, null, id)
        return r == TextToSpeech.SUCCESS
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val ch = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
        channel = ch
        ch.setMethodCallHandler { call, result ->
            when (call.method) {
                "getBatteryInfo" -> result.success(getBatteryInfo())
                "getDeviceInfo" -> result.success(getDeviceInfo())
                "speak" -> {
                    val text = call.argument<String>("text") ?: ""
                    result.success(if (text.isBlank()) false else speak(text))
                }
                "stopSpeak" -> {
                    tts?.stop()
                    result.success(true)
                }
                "ttsStatus" -> result.success(
                    mapOf("ready" to ttsReady, "language" to ttsLangLabel)
                )
                "getSpeechEnabled" -> result.success(
                    getSharedPreferences("charge_sach", Context.MODE_PRIVATE)
                        .getBoolean("speech_enabled", true)
                )
                "setSpeechEnabled" -> {
                    val enabled = call.argument<Boolean>("enabled") ?: true
                    getSharedPreferences("charge_sach", Context.MODE_PRIVATE)
                        .edit().putBoolean("speech_enabled", enabled).apply()
                    if (!enabled) tts?.stop()
                    result.success(true)
                }
                "canWriteSettings" -> result.success(Settings.System.canWrite(this))
                "openWriteSettings" -> {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_WRITE_SETTINGS,
                        Uri.parse("package:$packageName")
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                    result.success(true)
                }
                "getBrightness" -> result.success(getBrightness())
                "setBrightnessMin" -> result.success(setBrightness(1, manual = true))
                "restoreBrightness" -> {
                    val value = call.argument<Int>("value") ?: 125
                    val manual = call.argument<Boolean>("manual") ?: true
                    result.success(setBrightness(value, manual))
                }
                "isPowerSaveMode" -> {
                    val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                    result.success(pm.isPowerSaveMode)
                }
                "openBatterySaverSettings" -> {
                    openSettingsAction(Settings.ACTION_BATTERY_SAVER_SETTINGS)
                    result.success(true)
                }
                "openWifiSettings" -> {
                    openSettingsAction(Settings.ACTION_WIFI_SETTINGS)
                    result.success(true)
                }
                "openBluetoothSettings" -> {
                    openSettingsAction(Settings.ACTION_BLUETOOTH_SETTINGS)
                    result.success(true)
                }
                "getRadioStates" -> result.success(getRadioStates())
                else -> result.notImplemented()
            }
        }
    }

    private fun openSettingsAction(action: String) {
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            // Kisi phone par ye screen na ho to aam settings khol do.
            startActivity(
                Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    /** BatteryManager + sticky battery intent se tamam asal readings. */
    private fun getBatteryInfo(): Map<String, Any?> {
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val sticky = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

        fun longProp(id: Int): Long? {
            val v = bm.getLongProperty(id)
            return if (v == Long.MIN_VALUE) null else v
        }
        fun intProp(id: Int): Int? {
            val v = bm.getIntProperty(id)
            return if (v == Int.MIN_VALUE) null else v
        }

        val level = sticky?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = sticky?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val percentFromIntent =
            if (level >= 0 && scale > 0) (level * 100) / scale else null

        return mapOf(
            // Battery % — pehle BATTERY_PROPERTY_CAPACITY, warna sticky intent.
            "capacityPercent" to (intProp(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                ?: percentFromIntent),
            // 1=unknown 2=charging 3=discharging 4=not charging 5=full
            "statusCode" to (intProp(BatteryManager.BATTERY_PROPERTY_STATUS)
                ?: sticky?.getIntExtra(BatteryManager.EXTRA_STATUS, 1)),
            // Micro-amp mein asal current. Alamat (sign) har company ke
            // phone par mukhtalif hoti hai — app hamesha asal tadaad
            // (absolute) dikhati hai.
            "currentMicroA" to longProp(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW),
            "chargeCounterMicroAh" to longProp(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER),
            "energyCounterNanoWh" to longProp(BatteryManager.BATTERY_PROPERTY_ENERGY_COUNTER),
            "voltageMv" to sticky?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
                ?.takeIf { it > 0 },
            // Temperature daswein hissay darjay mein aata hai (255 = 25.5°C).
            "temperatureTenthsC" to sticky?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
                ?.takeIf { it > 0 },
            // 1=unknown 2=good 3=overheat 4=dead 5=over voltage 6=failure 7=cold
            "healthCode" to sticky?.getIntExtra(BatteryManager.EXTRA_HEALTH, 1),
            "technology" to sticky?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY),
            // 0=koi nahi 1=AC 2=USB 4=wireless
            "pluggedCode" to (sticky?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0),
            "designCapacityMah" to designCapacityMah()
        )
    }

    /**
     * Battery ki design (asal kul) capacity mAh mein — Android ke
     * andar wali PowerProfile se reflection ke zariye. Ye chhupa hua
     * API hai, is liye har ghalti par -1 wapas jata hai aur app
     * "maloom nahi" dikhati hai. Jhooti tadaad kabhi nahi banti.
     */
    private fun designCapacityMah(): Double {
        return try {
            val clazz = Class.forName("com.android.internal.os.PowerProfile")
            val ctor = clazz.getConstructor(Context::class.java)
            val instance = ctor.newInstance(this)
            val method = clazz.getMethod("getBatteryCapacity")
            (method.invoke(instance) as? Double) ?: -1.0
        } catch (e: Exception) {
            -1.0
        }
    }

    private fun getBrightness(): Map<String, Any?> {
        val resolver = contentResolver
        val mode = try {
            Settings.System.getInt(resolver, Settings.System.SCREEN_BRIGHTNESS_MODE)
        } catch (e: Exception) {
            Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
        }
        val value = try {
            Settings.System.getInt(resolver, Settings.System.SCREEN_BRIGHTNESS)
        } catch (e: Exception) {
            125
        }
        return mapOf(
            "value" to value,
            "manual" to (mode == Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        )
    }

    private fun setBrightness(value: Int, manual: Boolean): Boolean {
        if (!Settings.System.canWrite(this)) return false
        return try {
            val resolver = contentResolver
            Settings.System.putInt(
                resolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                if (manual) Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                else Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
            )
            Settings.System.putInt(
                resolver, Settings.System.SCREEN_BRIGHTNESS, value.coerceIn(1, 255)
            )
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Postmortem ke liye mobile ki aam maloomat: model, Android
     * version, RAM aur storage. Ye sab Android ke aam APIs se asal
     * tadaad hain — koi andaza nahi.
     */
    private fun getDeviceInfo(): Map<String, Any?> {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mem)
        val stat = StatFs(Environment.getDataDirectory().path)
        val storageTotal = stat.blockCountLong * stat.blockSizeLong
        val storageFree = stat.availableBlocksLong * stat.blockSizeLong
        return mapOf(
            "manufacturer" to Build.MANUFACTURER,
            "model" to Build.MODEL,
            "androidRelease" to Build.VERSION.RELEASE,
            "sdkInt" to Build.VERSION.SDK_INT,
            "totalRamBytes" to mem.totalMem,
            "availRamBytes" to mem.availMem,
            "storageTotalBytes" to storageTotal,
            "storageFreeBytes" to storageFree
        )
    }

    /** Wi-Fi / Bluetooth ki haalat sirf PARHNA hai — badalna user ka kaam hai. */
    private fun getRadioStates(): Map<String, Any?> {
        val wifi = try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            wm.isWifiEnabled
        } catch (e: Exception) {
            null
        }
        val bluetooth = try {
            @Suppress("DEPRECATION")
            BluetoothAdapter.getDefaultAdapter()?.isEnabled
        } catch (e: Exception) {
            null
        }
        return mapOf("wifi" to wifi, "bluetooth" to bluetooth)
    }
}
