// Charge Sach — Battery Doctor
//
// Usool: koi jhoota dawa nahi. Software charger ki taaqat nahi badha
// sakta — ye hardware ki had hai. Ye app do asal kaam karti hai:
//  1. ASAL charging current nap kar dikhati hai (BatteryManager se),
//     taake user ko pata chale charger/cable asal mein kaisa hai.
//  2. Charge ke doran phone ki apni khapat kam karti hai (brightness
//     kam, battery saver ki rehnumai) — khapat kam ho to wohi current
//     battery ko zyada milta hai aur battery jaldi bharti hai.
//  3. BOL KAR batati hai — jaise phone khud baat kar raha ho. Saare
//     jumle asal nap-tol par bante hain.
//  4. Mobile ka POSTMORTEM karti hai — battery, cable, drain aur
//     mobile ki aam sehat ki report, screen par aur bol kar bhi.
//     Jahan data asal hai wahan "ASAL", jahan andaza hai wahan
//     "ANDAZA" saaf likha jata hai.

import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

const MethodChannel _channel = MethodChannel('com.bozdar.chargesach/battery');

const Color _bg = Color(0xFF07271B);
const Color _surface = Color(0xFF0E3B2A);
const Color _surfaceLight = Color(0xFF14532D);
const Color _green = Color(0xFF22A565);
const Color _gold = Color(0xFFF2C230);
const Color _red = Color(0xFFEF5350);

void main() {
  runApp(const ChargeSachApp());
}

class ChargeSachApp extends StatelessWidget {
  const ChargeSachApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Charge Sach',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: _bg,
        colorScheme: const ColorScheme.dark(
          primary: _green,
          secondary: _gold,
          surface: _surface,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: _surface,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        cardTheme: const CardTheme(
          color: _surface,
          elevation: 2,
          margin: EdgeInsets.symmetric(vertical: 6),
        ),
        textTheme: const TextTheme(
          bodyLarge: TextStyle(fontSize: 18, color: Colors.white),
          bodyMedium: TextStyle(fontSize: 16, color: Colors.white70),
        ),
      ),
      home: const HomeShell(),
    );
  }
}

/// BatteryManager se aayi hui ek reading. Jo cheez phone nahi deta
/// wo null rehti hai — app wahan "nahi milta" likhti hai.
class BatteryInfo {
  final int? percent;
  final int statusCode; // 2 charging, 3 discharging, 4 not charging, 5 full
  final int? currentMicroA;
  final int? chargeCounterMicroAh;
  final int? voltageMv;
  final int? temperatureTenthsC;
  final int healthCode;
  final String? technology;
  final int pluggedCode; // 0 none, 1 AC, 2 USB, 4 wireless
  final double designCapacityMah;

  const BatteryInfo({
    required this.percent,
    required this.statusCode,
    required this.currentMicroA,
    required this.chargeCounterMicroAh,
    required this.voltageMv,
    required this.temperatureTenthsC,
    required this.healthCode,
    required this.technology,
    required this.pluggedCode,
    required this.designCapacityMah,
  });

  factory BatteryInfo.fromMap(Map<dynamic, dynamic> m) {
    return BatteryInfo(
      percent: m['capacityPercent'] as int?,
      statusCode: (m['statusCode'] as int?) ?? 1,
      currentMicroA: m['currentMicroA'] as int?,
      chargeCounterMicroAh: m['chargeCounterMicroAh'] as int?,
      voltageMv: m['voltageMv'] as int?,
      temperatureTenthsC: m['temperatureTenthsC'] as int?,
      healthCode: (m['healthCode'] as int?) ?? 1,
      technology: m['technology'] as String?,
      pluggedCode: (m['pluggedCode'] as int?) ?? 0,
      designCapacityMah: (m['designCapacityMah'] as num?)?.toDouble() ?? -1,
    );
  }

  bool get plugged => pluggedCode != 0;
  bool get charging => statusCode == 2;
  bool get full => statusCode == 5 || (percent != null && percent! >= 100);

  /// Asal current milli-amp mein. Sign har company ke phone par
  /// mukhtalif hota hai, is liye hamesha asal tadaad (absolute).
  int? get currentMa {
    final c = currentMicroA;
    if (c == null) return null;
    return (c.abs() / 1000).round();
  }

  double? get voltageV =>
      voltageMv == null ? null : voltageMv! / 1000.0;

  double? get temperatureC =>
      temperatureTenthsC == null ? null : temperatureTenthsC! / 10.0;

  double? get chargeCounterMah => chargeCounterMicroAh == null
      ? null
      : chargeCounterMicroAh! / 1000.0;

  String get sourceLabel {
    switch (pluggedCode) {
      case 1:
        return 'AC Charger (bajli wala)';
      case 2:
        return 'USB (computer / power bank)';
      case 4:
        return 'Wireless Charger';
      default:
        return 'Battery par chal raha hai';
    }
  }

  String get statusLabel {
    if (full) return 'Battery full hai';
    if (charging) return 'Charge ho rahi hai';
    if (plugged) return 'Charger laga hai, charge nahi ho rahi';
    return 'Charge nahi ho rahi';
  }

  String get healthLabel {
    switch (healthCode) {
      case 2:
        return 'Achi hai';
      case 3:
        return 'Battery bohat garam hai';
      case 4:
        return 'Battery kharab (dead) hai';
      case 5:
        return 'Voltage zyada hai';
      case 6:
        return 'Battery fail hai';
      case 7:
        return 'Battery bohat thandi hai';
      default:
        return 'Maloom nahi';
    }
  }

  /// Isi raftar se full honay ka andaza waqt. Asal capacity pehle
  /// design capacity se, warna charge counter se nikalti hai.
  /// Data na mile to null — jhoota andaza nahi lagta.
  Duration? get etaToFull {
    if (!charging) return null;
    final ma = currentMa;
    final pct = percent;
    if (ma == null || ma <= 0 || pct == null || pct >= 100) return null;
    double? fullMah;
    if (designCapacityMah > 0) {
      fullMah = designCapacityMah;
    } else if (chargeCounterMah != null && pct >= 20) {
      fullMah = chargeCounterMah! / (pct / 100.0);
    }
    if (fullMah == null) return null;
    final remainingMah = fullMah * (100 - pct) / 100.0;
    final hours = remainingMah / ma;
    if (hours.isNaN || hours.isInfinite || hours < 0) return null;
    return Duration(minutes: (hours * 60).round());
  }
}

class DeviceInfo {
  final String manufacturer;
  final String model;
  final String androidRelease;
  final int sdkInt;
  final int totalRamBytes;
  final int availRamBytes;
  final int storageTotalBytes;
  final int storageFreeBytes;

  const DeviceInfo({
    required this.manufacturer,
    required this.model,
    required this.androidRelease,
    required this.sdkInt,
    required this.totalRamBytes,
    required this.availRamBytes,
    required this.storageTotalBytes,
    required this.storageFreeBytes,
  });

  factory DeviceInfo.fromMap(Map<dynamic, dynamic> m) {
    return DeviceInfo(
      manufacturer: (m['manufacturer'] as String?) ?? '',
      model: (m['model'] as String?) ?? 'Maloom nahi',
      androidRelease: (m['androidRelease'] as String?) ?? '',
      sdkInt: (m['sdkInt'] as int?) ?? 0,
      totalRamBytes: (m['totalRamBytes'] as int?) ?? 0,
      availRamBytes: (m['availRamBytes'] as int?) ?? 0,
      storageTotalBytes: (m['storageTotalBytes'] as int?) ?? 0,
      storageFreeBytes: (m['storageFreeBytes'] as int?) ?? 0,
    );
  }
}

String _gb(int bytes) =>
    bytes <= 0 ? '—' : (bytes / (1024 * 1024 * 1024)).toStringAsFixed(1);

String _durationText(Duration d) {
  final h = d.inHours;
  final m = d.inMinutes % 60;
  if (h > 0 && m > 0) return '$h ghanta $m minute';
  if (h > 0) return '$h ghanta';
  return '$m minute';
}

/// Charger baghair battery girne ka ek sample (drain check ke liye).
class DrainSample {
  final DateTime time;
  final int percent;
  const DrainSample(this.time, this.percent);
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  BatteryInfo? _info;
  Timer? _timer;
  int _tab = 0;

  // --- Bolne wali khidmat ki haalat ---
  bool _speechOn = true;
  String _ttsLanguage = '';
  bool _ttsReady = false;
  int? _lastMilestone; // aakhri elan shuda 10% ka step
  DateTime? _lastSlowWarn;
  bool _low20Spoken = false;
  bool _low10Spoken = false;
  bool _fullSpoken = false;

  // --- Tez Charge Mode ki haalat ---
  bool _tezMode = false;
  int? _savedBrightness;
  bool _savedBrightnessManual = true;
  bool? _powerSave;
  bool? _wifiOn;
  bool? _bluetoothOn;

  // --- Drain check ka record (charger baghair ke samples) ---
  final List<DrainSample> _drainSamples = [];

  @override
  void initState() {
    super.initState();
    _channel.setMethodCallHandler(_nativeCall);
    _initSpeech();
    _refresh();
    _timer = Timer.periodic(const Duration(seconds: 2), (_) => _refresh());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _initSpeech() async {
    try {
      final on = await _channel.invokeMethod<bool>('getSpeechEnabled');
      final st =
          await _channel.invokeMethod<Map<dynamic, dynamic>>('ttsStatus');
      if (!mounted) return;
      setState(() {
        _speechOn = on ?? true;
        _ttsReady = (st?['ready'] as bool?) ?? false;
        _ttsLanguage = (st?['language'] as String?) ?? '';
      });
    } catch (_) {
      // TTS na ho to khamoshi — app baqi chalti rehti hai.
    }
  }

  Future<void> _refresh() async {
    try {
      final m =
          await _channel.invokeMethod<Map<dynamic, dynamic>>('getBatteryInfo');
      if (m == null || !mounted) return;
      final info = BatteryInfo.fromMap(m);
      setState(() => _info = info);
      _trackDrain(info);
      _announce(info);
      _refreshModeStates();
    } catch (_) {
      // Reading na mile to purani reading rehne do.
    }
  }

  Future<void> _refreshModeStates() async {
    try {
      final ps = await _channel.invokeMethod<bool>('isPowerSaveMode');
      final radios =
          await _channel.invokeMethod<Map<dynamic, dynamic>>('getRadioStates');
      if (!mounted) return;
      setState(() {
        _powerSave = ps;
        _wifiOn = radios?['wifi'] as bool?;
        _bluetoothOn = radios?['bluetooth'] as bool?;
      });
    } catch (_) {}
  }

  // ---------------- Bolne wali khidmat ----------------

  Future<void> _speak(String text, {bool force = false}) async {
    if (!_speechOn && !force) return;
    try {
      await _channel.invokeMethod('speak', {'text': text});
    } catch (_) {}
  }

  /// Native taraf se charger lagne/nikalne ki khabar.
  Future<dynamic> _nativeCall(MethodCall call) async {
    if (call.method != 'onPowerEvent') return null;
    final args = call.arguments as Map<dynamic, dynamic>?;
    final type = args?['type'] as String?;
    final pct = args?['percent'] as int?;
    if (type == 'connected') {
      // Current ko set honay ka waqt do, phir asal reading bolna.
      await Future<void>.delayed(const Duration(seconds: 3));
      await _refresh();
      final i = _info;
      if (i == null) return null;
      final b = StringBuffer('Charger lag gaya.');
      final v = i.voltageV;
      final ma = i.currentMa;
      if (v != null && ma != null) {
        b.write(
            ' Mujhe ${v.toStringAsFixed(1)} volt aur $ma milliampere current mil raha hai.');
      }
      if (ma != null) {
        if (ma < 500) {
          b.write(
              ' Ye charger sahi nahi hai, dusra charger lagao. Mujhe current pura nahi mil raha.');
        } else if (ma >= 1500) {
          b.write(' Ye charger acha hai.');
        } else {
          b.write(' Charger darmiyana hai, tez nahi hai.');
        }
      }
      // Mukhtasar sehat report: masla ho to charger wali khabar ke
      // saath hi bata do.
      final t = i.temperatureC;
      if (i.healthCode == 4 || i.healthCode == 6) {
        b.write(' Lekin meri battery kharab lagti hai.');
      } else if (t != null && t >= 45) {
        b.write(' Lekin mein bohat garam hoon, mujhe thandi jagah rakho.');
      }
      _speak(b.toString());
    } else if (type == 'disconnected') {
      final p = pct ?? _info?.percent;
      _speak(p != null
          ? 'Charger nikal gaya. Battery ab $p percent hai.'
          : 'Charger nikal gaya.');
    }
    return null;
  }

  /// Har refresh par waqfe wale elan (milestone, slow, low, full).
  void _announce(BatteryInfo i) {
    final pct = i.percent;
    if (pct == null) return;

    if (i.plugged) {
      _low20Spoken = false;
      _low10Spoken = false;

      // Har 10% barhne par elan.
      final milestone = (pct ~/ 10) * 10;
      if (_lastMilestone == null) {
        _lastMilestone = milestone;
      } else {
        if (milestone > _lastMilestone! && pct < 100) {
          _speak('Battery $pct percent ho gayi hai.');
        }
        if (milestone > _lastMilestone!) _lastMilestone = milestone;
      }

      // Slow charge ki darmiyan mein chetaoni (har 15 minute se
      // zyada nahi, taake user tang na ho).
      final ma = i.currentMa;
      if (i.charging && ma != null && ma < 500) {
        final now = DateTime.now();
        if (_lastSlowWarn == null ||
            now.difference(_lastSlowWarn!) >= const Duration(minutes: 15)) {
          _lastSlowWarn = now;
          _speak('Charge bohat slow ho raha hai, mujhe zyada current chahiye.');
        }
      }

      // 100% ka elan — ek dafa.
      if (pct >= 100 && !_fullSpoken) {
        _fullSpoken = true;
        _speak('Mera pait bhar gaya, battery full ho gayi. Charger nikal dein.');
      }
    } else {
      if (pct < 98) _fullSpoken = false;
      _lastMilestone = null;

      if (pct <= 10 && !_low10Spoken) {
        _low10Spoken = true;
        _low20Spoken = true;
        _speak(
            'Bohat zyada bhookh lagi hai, jaldi charger lagao, warna mein band ho jaunga.');
      } else if (pct <= 20 && !_low20Spoken) {
        _low20Spoken = true;
        _speak('Mujhe bhookh lagi hai, charger lagao.');
      }
      if (pct > 25) {
        _low20Spoken = false;
        _low10Spoken = false;
      }
    }
  }

  /// "Abhi sunao" — mojooda haalat foran bol kar sunao. Ye user ka
  /// apna dabana hai, is liye toggle OFF ho tab bhi bolta hai.
  Future<void> _speakNow() async {
    final i = _info;
    if (i == null || i.percent == null) {
      _speak('Abhi battery ki reading nahi mil rahi.', force: true);
      return;
    }
    final b = StringBuffer('Battery ab ${i.percent} percent hai.');
    if (i.plugged) {
      b.write(' Charger laga hai.');
      final ma = i.currentMa;
      if (ma != null) {
        b.write(' Mujhe $ma milliampere current mil raha hai.');
        if (ma < 500) {
          b.write(' Ye charger slow hai.');
        } else if (ma >= 1500) {
          b.write(' Ye charger tez hai.');
        }
      }
      final eta = i.etaToFull;
      if (eta != null) {
        b.write(' Full honay mein taqreeban ${_durationText(eta)} lagein ge.');
      }
    } else {
      b.write(' Charger nahi laga.');
    }
    _speak(b.toString(), force: true);
  }

  // ---------------- Drain record ----------------

  void _trackDrain(BatteryInfo i) {
    if (i.plugged || i.percent == null) return;
    final now = DateTime.now();
    if (_drainSamples.isNotEmpty &&
        now.difference(_drainSamples.last.time) <
            const Duration(minutes: 1)) {
      return;
    }
    _drainSamples.add(DrainSample(now, i.percent!));
    // 2 ghante se purana record saaf kar do.
    _drainSamples.removeWhere(
        (s) => now.difference(s.time) > const Duration(hours: 2));
  }

  // ---------------- Tez Charge Mode ----------------

  Future<void> _tezModeOn() async {
    // Pehle purani brightness yaad rakho, taake wapas ho sake.
    try {
      final b =
          await _channel.invokeMethod<Map<dynamic, dynamic>>('getBrightness');
      _savedBrightness = b?['value'] as int?;
      _savedBrightnessManual = (b?['manual'] as bool?) ?? true;
    } catch (_) {}

    bool ok = false;
    try {
      ok = await _channel.invokeMethod<bool>('canWriteSettings') ?? false;
      if (!ok) {
        // Ijazat ki screen khol do — faisla user ka hai.
        await _channel.invokeMethod('openWriteSettings');
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text(
              'Brightness kam karne ki ijazat dein, phir dobara Tez Charge Mode dabayein.'),
          duration: Duration(seconds: 5),
        ));
        return;
      }
      ok = await _channel.invokeMethod<bool>('setBrightnessMin') ?? false;
    } catch (_) {}
    if (!mounted) return;
    setState(() => _tezMode = ok);
    _refreshModeStates();
  }

  Future<void> _tezModeOff() async {
    try {
      if (_savedBrightness != null) {
        await _channel.invokeMethod('restoreBrightness', {
          'value': _savedBrightness,
          'manual': _savedBrightnessManual,
        });
      }
    } catch (_) {}
    if (!mounted) return;
    setState(() => _tezMode = false);
  }

  // ---------------- UI ----------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Charge Sach — Battery Doctor',
            style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: _tab == 0 ? _homePage() : _healthPage(),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _tab,
        onTap: (t) => setState(() => _tab = t),
        backgroundColor: _surface,
        selectedItemColor: _gold,
        unselectedItemColor: Colors.white60,
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.battery_charging_full), label: 'Home'),
          BottomNavigationBarItem(
              icon: Icon(Icons.favorite), label: 'Battery Sehat'),
        ],
      ),
    );
  }

  Widget _homePage() {
    final i = _info;
    if (i == null) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(color: _gold),
            SizedBox(height: 16),
            Text('Battery ki reading li ja rahi hai...',
                style: TextStyle(fontSize: 18)),
          ],
        ),
      );
    }
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _bigPercent(i),
        const SizedBox(height: 8),
        _verdictBanner(i),
        _infoCard('Asal Current',
            i.currentMa == null ? 'Is phone par nahi milti' : '${i.currentMa} mA',
            Icons.electric_bolt),
        _infoCard(
            'Voltage',
            i.voltageV == null
                ? '—'
                : '${i.voltageV!.toStringAsFixed(2)} V',
            Icons.flash_on),
        _infoCard(
            'Battery ka Darja Hararat',
            i.temperatureC == null
                ? '—'
                : '${i.temperatureC!.toStringAsFixed(1)} °C',
            Icons.thermostat),
        _infoCard('Taqat ka Zariya', i.sourceLabel, Icons.power),
        _infoCard(
            'Full Honay ka Andaza Waqt',
            i.etaToFull == null
                ? (i.full
                    ? 'Battery full hai'
                    : 'Andaza nahi lag sakta')
                : 'Taqreeban ${_durationText(i.etaToFull!)}',
            Icons.timer),
        const SizedBox(height: 8),
        _postmortemButton(),
        const SizedBox(height: 8),
        _tezModeCard(),
        const SizedBox(height: 8),
        _speechCard(),
        const SizedBox(height: 12),
        const Text(
          'Note: Koi bhi app charger ki taaqat nahi badha sakti — ye '
          'charger, cable aur phone ke hardware ki had hai. Ye app '
          'asal current dikhati hai aur phone ki khapat kam karke '
          'charge jaldi bharne mein madad karti hai.',
          style: TextStyle(fontSize: 14, color: Colors.white60),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _bigPercent(BatteryInfo i) {
    return Column(
      children: [
        Text(
          i.percent == null ? '—' : '${i.percent}%',
          style: TextStyle(
            fontSize: 84,
            fontWeight: FontWeight.bold,
            color: i.full ? _gold : Colors.white,
          ),
        ),
        Text(i.statusLabel,
            style: const TextStyle(fontSize: 20, color: Colors.white70)),
      ],
    );
  }

  Widget _verdictBanner(BatteryInfo i) {
    if (!i.plugged) return const SizedBox.shrink();
    final ma = i.currentMa;
    if (ma == null) {
      return _banner(
          'Charger laga hai — is phone par current ki reading nahi milti, '
          'is liye charger ka faisla nahi ho sakta.',
          _surfaceLight);
    }
    if (ma >= 1500) {
      return _banner('Charger tez hai — $ma mA current mil raha hai.', _green);
    }
    if (ma >= 500) {
      return _banner(
          'Charger darmiyana hai — $ma mA current mil raha hai.', _surfaceLight);
    }
    return _banner(
        'Charger slow hai — sirf $ma mA mil raha hai. Zyada watt wala '
        'charger lagayein. App charger ki taaqat nahi badha sakti.',
        _red);
  }

  Widget _banner(String text, Color color) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(text,
          style: const TextStyle(
              fontSize: 19, fontWeight: FontWeight.bold, color: Colors.white)),
    );
  }

  Widget _infoCard(String label, String value, IconData icon) {
    return Card(
      child: ListTile(
        leading: Icon(icon, color: _gold, size: 30),
        title: Text(label,
            style: const TextStyle(fontSize: 15, color: Colors.white60)),
        subtitle: Text(value,
            style: const TextStyle(
                fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white)),
      ),
    );
  }

  Widget _postmortemButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          backgroundColor: _gold,
          foregroundColor: Colors.black,
          padding: const EdgeInsets.symmetric(vertical: 16),
          textStyle: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
        ),
        icon: const Icon(Icons.medical_services, size: 26),
        label: const Text('Postmortem Karo'),
        onPressed: () {
          Navigator.of(context).push(MaterialPageRoute<void>(
            builder: (_) => PostmortemScreen(
              drainSamples: List<DrainSample>.of(_drainSamples),
              speak: (t) => _speak(t),
            ),
          ));
        },
      ),
    );
  }

  Widget _tezModeCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Tez Charge Mode',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text(
              'Ye mode phone ki khapat kam karta hai taake battery jaldi '
              'bhare. Charger ki taaqat app nahi badha sakti.',
              style: TextStyle(fontSize: 16, color: Colors.white70),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: _tezMode ? _red : _green,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  textStyle: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.bold),
                ),
                onPressed: _tezMode ? _tezModeOff : _tezModeOn,
                child: Text(_tezMode
                    ? 'Tez Charge Mode BAND karo'
                    : 'Tez Charge Mode ON karo'),
              ),
            ),
            if (_tezMode) ...[
              const SizedBox(height: 6),
              const Text('Screen ki roshni sab se kam kar di gayi hai.',
                  style: TextStyle(fontSize: 15, color: _gold)),
            ],
            const Divider(color: Colors.white24),
            _settingRow(
              'Battery Saver',
              _powerSave == null
                  ? 'Haalat maloom nahi'
                  : (_powerSave! ? 'ON hai' : 'OFF hai'),
              'Settings kholo',
              () => _channel.invokeMethod('openBatterySaverSettings'),
            ),
            _settingRow(
              'Wi-Fi',
              _wifiOn == null
                  ? 'Haalat maloom nahi'
                  : (_wifiOn! ? 'ON hai' : 'OFF hai'),
              'Settings kholo',
              () => _channel.invokeMethod('openWifiSettings'),
            ),
            _settingRow(
              'Bluetooth',
              _bluetoothOn == null
                  ? 'Haalat maloom nahi'
                  : (_bluetoothOn! ? 'ON hai' : 'OFF hai'),
              'Settings kholo',
              () => _channel.invokeMethod('openBluetoothSettings'),
            ),
            const Text(
              'Wi-Fi aur Bluetooth app khud band nahi karti — button se '
              'settings khulti hai, band karna aap ka apna faisla hai.',
              style: TextStyle(fontSize: 13, color: Colors.white54),
            ),
          ],
        ),
      ),
    );
  }

  Widget _settingRow(
      String label, String state, String buttonText, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(
            child: Text('$label: $state', style: const TextStyle(fontSize: 17)),
          ),
          OutlinedButton(
            onPressed: onTap,
            child: Text(buttonText),
          ),
        ],
      ),
    );
  }

  Widget _speechCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Bolne Wali Khidmat',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text(
              'Phone khud bol kar apni haalat batata hai — charger lagne '
              'par, charge barhne par, battery kam honay par aur full '
              'honay par.',
              style: TextStyle(fontSize: 16, color: Colors.white70),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Awaz se bataye',
                  style: TextStyle(fontSize: 18)),
              subtitle: Text(
                _ttsReady
                    ? 'Awaz tayyar hai${_ttsLanguage.isEmpty ? '' : ' — $_ttsLanguage'}'
                    : 'Awaz tayyar ho rahi hai...',
                style: const TextStyle(fontSize: 14, color: Colors.white54),
              ),
              value: _speechOn,
              activeColor: _gold,
              onChanged: (v) async {
                setState(() => _speechOn = v);
                try {
                  await _channel
                      .invokeMethod('setSpeechEnabled', {'enabled': v});
                } catch (_) {}
              },
            ),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                icon: const Icon(Icons.volume_up),
                label: const Text('Abhi Sunao',
                    style: TextStyle(fontSize: 18)),
                onPressed: _speakNow,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Awaz tab aati hai jab app khuli ho. App band kar dein to '
              'phone khamosh rahega.',
              style: TextStyle(fontSize: 13, color: Colors.white54),
            ),
          ],
        ),
      ),
    );
  }

  Widget _healthPage() {
    final i = _info;
    if (i == null) {
      return const Center(child: CircularProgressIndicator(color: _gold));
    }
    final counter = i.chargeCounterMah;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Battery ki Sehat',
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        _infoCard('Sehat ki Haalat', i.healthLabel, Icons.favorite),
        _infoCard('Battery ki Qisam (Technology)',
            i.technology ?? 'Maloom nahi', Icons.science),
        _infoCard(
            'Abhi Battery mein Charge',
            counter == null
                ? 'Is phone par nahi milta'
                : '${counter.toStringAsFixed(0)} mAh',
            Icons.battery_std),
        _infoCard(
            'Battery ki Kul Capacity (andaza)',
            i.designCapacityMah > 0
                ? '${i.designCapacityMah.toStringAsFixed(0)} mAh'
                : 'Is phone par nahi milta',
            Icons.battery_full),
        _infoCard(
            'Darja Hararat',
            i.temperatureC == null
                ? '—'
                : '${i.temperatureC!.toStringAsFixed(1)} °C',
            Icons.thermostat),
        const SizedBox(height: 10),
        const Text(
          'Note: Capacity ka andaza phone ke apne record se aata hai. '
          'Kuch phones ye data nahi dete — wahan app jhooti tadaad '
          'banaanay ke bajaye saaf likh deti hai ke data nahi milta. '
          'Puri tafseel ke liye Home par "Postmortem Karo" dabayein.',
          style: TextStyle(fontSize: 14, color: Colors.white60),
        ),
      ],
    );
  }
}

// =====================================================================
// MOBILE POSTMORTEM
// Battery, cable/current, drain aur mobile ki aam sehat ki puri
// report — screen par tafseel aur bol kar khulasa.
// Har line ke saath saaf likha jata hai: ASAL (naapi hui cheez) ya
// ANDAZA (hisab se nikali hui) ya DATA NAHI MILTA. Root ke baghair
// jo cheez naapi nahi ja sakti, us ka dawa nahi hota.
// =====================================================================

class PostmortemScreen extends StatefulWidget {
  final List<DrainSample> drainSamples;
  final Future<void> Function(String text) speak;

  const PostmortemScreen({
    super.key,
    required this.drainSamples,
    required this.speak,
  });

  @override
  State<PostmortemScreen> createState() => _PostmortemScreenState();
}

class _ReportLine {
  final String title;
  final String value;
  final String tag; // 'ASAL' | 'ANDAZA' | 'DATA NAHI'
  final bool warning;
  const _ReportLine(this.title, this.value, this.tag, {this.warning = false});
}

class _PostmortemScreenState extends State<PostmortemScreen> {
  bool _running = true;
  bool _cancelled = false;
  String _stage = 'Battery ki reading li ja rahi hai...';
  int _sampleCount = 0;
  final List<_ReportLine> _lines = [];
  String _summary = '';

  @override
  void initState() {
    super.initState();
    _run();
  }

  @override
  void dispose() {
    _cancelled = true;
    super.dispose();
  }

  Future<BatteryInfo?> _readInfo() async {
    try {
      final m =
          await _channel.invokeMethod<Map<dynamic, dynamic>>('getBatteryInfo');
      return m == null ? null : BatteryInfo.fromMap(m);
    } catch (_) {
      return null;
    }
  }

  Future<void> _run() async {
    setState(() {
      _running = true;
      _lines.clear();
      _summary = '';
      _sampleCount = 0;
      _stage = 'Battery ki reading li ja rahi hai...';
    });

    final issues = <String>[];
    var batteryGood = false;
    var chargerGood = false;

    final info = await _readInfo();
    if (_cancelled) return;
    if (info == null) {
      setState(() {
        _running = false;
        _stage = 'Battery ki reading nahi mil saki. Dobara koshish karein.';
      });
      return;
    }

    // ---------- 1. Battery sehat (ASAL) ----------
    batteryGood = info.healthCode == 2;
    _lines.add(_ReportLine('Battery ki Sehat (system report)',
        info.healthLabel, 'ASAL',
        warning: !batteryGood && info.healthCode != 1));
    if (info.healthCode == 4 || info.healthCode == 6) {
      issues.add('Battery kharab lagti hai');
    } else if (info.healthCode == 3) {
      issues.add('Battery bohat garam hai');
    } else if (info.healthCode == 5) {
      issues.add('Battery ka voltage zyada hai');
    }

    final t = info.temperatureC;
    if (t == null) {
      _lines.add(const _ReportLine(
          'Battery ka Darja Hararat', 'Is mobile mein ye data nahi milta', 'DATA NAHI'));
    } else {
      final warn = t >= 40;
      _lines.add(_ReportLine(
        'Battery ka Darja Hararat',
        '${t.toStringAsFixed(1)} °C${t >= 45 ? ' — bohat garam hai!' : t >= 40 ? ' — garam hai, ehtiyat karein' : ' — theek hai'}',
        'ASAL',
        warning: warn,
      ));
      if (t >= 45 && info.healthCode != 3) {
        issues.add('Battery bohat garam hai');
      }
    }

    final v = info.voltageV;
    if (v == null) {
      _lines.add(const _ReportLine(
          'Battery Voltage', 'Is mobile mein ye data nahi milta', 'DATA NAHI'));
    } else {
      final String halat;
      var warn = false;
      if (v > 4.45) {
        halat = 'Voltage zyada hai';
        warn = true;
      } else if (v < 3.3) {
        halat = 'Voltage kam hai (battery khali honay par aam hai)';
      } else {
        halat = 'Voltage theek hai';
      }
      _lines.add(_ReportLine('Battery Voltage',
          '${v.toStringAsFixed(2)} V — $halat', 'ASAL',
          warning: warn));
    }

    // ---------- 2. Battery ki umar / sehat ka ANDAZA ----------
    final counterMah = info.chargeCounterMah;
    final pct = info.percent;
    double? healthPct;
    if (counterMah != null &&
        pct != null &&
        pct >= 20 &&
        info.designCapacityMah > 0) {
      final estFullMah = counterMah / (pct / 100.0);
      healthPct = estFullMah / info.designCapacityMah * 100.0;
      if (healthPct > 100) healthPct = 100;
      final label = healthPct >= 80
          ? 'achi haalat mein hai'
          : healthPct >= 60
              ? 'purani honay lagi hai'
              : 'kamzor ho gayi hai — badalne ka waqt aa raha hai';
      _lines.add(_ReportLine(
        'Battery ki Sehat ka Andaza',
        'Takreeban ${healthPct.toStringAsFixed(0)}% — battery $label '
        '(kul capacity ka andaza ${estFullMah.toStringAsFixed(0)} mAh, '
        'asal design ${info.designCapacityMah.toStringAsFixed(0)} mAh)',
        'ANDAZA',
        warning: healthPct < 60,
      ));
      if (healthPct < 60) issues.add('Battery kamzor ho gayi hai');
    } else {
      _lines.add(const _ReportLine(
        'Battery ki Sehat ka Andaza',
        'Is mobile mein ye data nahi milta — charge counter ya design '
        'capacity ki reading nahi aayi, is liye andaza nahi lagaya gaya',
        'DATA NAHI',
      ));
    }

    // ---------- 3. Current stability check (10 second) ----------
    if (info.plugged) {
      setState(() => _stage = 'Current ki checking ho rahi hai — 10 second...');
      final samples = <int>[];
      for (var s = 0; s < 10; s++) {
        await Future<void>.delayed(const Duration(seconds: 1));
        if (_cancelled) return;
        final r = await _readInfo();
        if (_cancelled) return;
        final ma = r?.currentMa;
        if (ma != null) samples.add(ma);
        setState(() => _sampleCount = s + 1);
      }
      final latest = await _readInfo();
      if (_cancelled) return;
      final lastMa = latest?.currentMa ?? info.currentMa;

      if (samples.length < 5) {
        _lines.add(const _ReportLine(
          'Current Stability Check',
          'Is mobile mein current ki reading theek se nahi milti — '
          'cable ki checking nahi ho saki',
          'DATA NAHI',
        ));
      } else {
        final avg = samples.reduce((a, b) => a + b) / samples.length;
        final mn = samples.reduce(math.min);
        final mx = samples.reduce(math.max);
        final unstable = mn == 0 ||
            (avg > 0 && mn < 0.35 * avg) ||
            (avg > 0 && (mx - mn) > 0.7 * avg);
        if (unstable) {
          issues.add('Cable ya charging pin mein kharabi lagti hai');
          _lines.add(_ReportLine(
            'Current Stability Check',
            'Current bar bar girta/charhta raha (sab se kam $mn mA, '
            'sab se zyada $mx mA, average ${avg.toStringAsFixed(0)} mA). '
            'Cable ya charging pin mein kharabi lagti hai — cable badal '
            'kar dekho, pin saaf karo.',
            'ASAL',
            warning: true,
          ));
        } else {
          _lines.add(_ReportLine(
            'Current Stability Check',
            'Current barabar raha (average ${avg.toStringAsFixed(0)} mA, '
            'kam $mn — zyada $mx mA). Cable aur pin theek lagte hain. '
            'Note: kuch phones current ki reading der se badalte hain.',
            'ASAL',
          ));
        }
        if (!unstable && lastMa != null && lastMa >= 500) chargerGood = true;
        if (lastMa != null && lastMa < 500) {
          issues.add('Charger slow hai');
        }
      }
      _lines.add(_ReportLine(
        'Charger ka Faisla',
        lastMa == null
            ? 'Current ki reading nahi mili'
            : lastMa >= 1500
                ? 'Charger tez hai — $lastMa mA'
                : lastMa >= 500
                    ? 'Charger darmiyana hai — $lastMa mA'
                    : 'Charger slow hai — sirf $lastMa mA. Zyada watt wala charger lagayein.',
        'ASAL',
        warning: lastMa != null && lastMa < 500,
      ));
    } else {
      _lines.add(const _ReportLine(
        'Current Stability Check',
        'Charger laga nahi hai — cable ki checking ke liye charger '
        'laga kar postmortem karein',
        'DATA NAHI',
      ));
    }

    // ---------- 4. Battery drain check ----------
    final samplesD = widget.drainSamples;
    if (samplesD.length >= 2) {
      final first = samplesD.first;
      final last = samplesD.last;
      final minutes = last.time.difference(first.time).inMinutes;
      final drop = first.percent - last.percent;
      if (minutes >= 10 && drop > 0) {
        final perHour = drop / (minutes / 60.0);
        final bad = perHour > 10;
        if (bad) {
          issues.add('Battery jaldi gir rahi hai');
        }
        _lines.add(_ReportLine(
          'Battery Drain Check',
          'Charger baghair $minutes minute mein $drop% battery giri — '
          'raftar takreeban ${perHour.toStringAsFixed(1)}% fi ghanta. '
          '${bad ? 'Ye ghair mamooli hai — battery purani ho gayi hai ya koi app zyada kha raha hai. Battery settings mein dekh kar zyada khane wali app band karein.' : 'Ye raftar aam hai.'}',
          'ANDAZA',
          warning: bad,
        ));
      } else {
        _lines.add(_ReportLine(
          'Battery Drain Check',
          'Abhi sirf $minutes minute ka record hai — drain ka andaza '
          'lagane ke liye app ko charger baghair kam az kam 10 minute '
          'khula rakhein',
          'DATA NAHI',
        ));
      }
    } else {
      _lines.add(const _ReportLine(
        'Battery Drain Check',
        'Abhi record nahi hai — app ko charger baghair kuch der khula '
        'rakhein, phir postmortem karein',
        'DATA NAHI',
      ));
    }

    // ---------- 5. Mobile ki aam sehat (ASAL) ----------
    try {
      final d = await _channel
          .invokeMethod<Map<dynamic, dynamic>>('getDeviceInfo');
      if (_cancelled) return;
      if (d != null) {
        final dev = DeviceInfo.fromMap(d);
        _lines.add(_ReportLine(
          'Mobile',
          '${dev.manufacturer} ${dev.model} — Android ${dev.androidRelease}',
          'ASAL',
        ));
        final usedGb =
            _gb(dev.storageTotalBytes - dev.storageFreeBytes);
        _lines.add(_ReportLine(
          'Storage',
          'Kul ${_gb(dev.storageTotalBytes)} GB — khali '
          '${_gb(dev.storageFreeBytes)} GB (bhara hua $usedGb GB)',
          'ASAL',
          warning: dev.storageTotalBytes > 0 &&
              dev.storageFreeBytes / dev.storageTotalBytes < 0.05,
        ));
        _lines.add(_ReportLine(
          'RAM',
          'Kul ${_gb(dev.totalRamBytes)} GB — abhi khali '
          '${_gb(dev.availRamBytes)} GB',
          'ASAL',
        ));
      }
    } catch (_) {
      _lines.add(const _ReportLine(
          'Mobile ki Maloomat', 'Is mobile mein ye data nahi milta', 'DATA NAHI'));
    }

    // ---------- Khulasa + bol kar sunao ----------
    final b = StringBuffer('Postmortem mukammal.');
    if (batteryGood) b.write(' Battery ki sehat achi hai.');
    if (chargerGood) b.write(' Charger theek hai.');
    if (issues.isEmpty) {
      b.write(' Mobile ke andar koi kharabi nahi mili.');
    } else {
      b.write(' Ye masle mile: ${issues.toSet().join('. ')}.');
    }
    _summary = b.toString();

    if (!mounted) return;
    setState(() => _running = false);
    widget.speak(_summary);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mobile Postmortem')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (_running) ...[
            const SizedBox(height: 30),
            const Center(child: CircularProgressIndicator(color: _gold)),
            const SizedBox(height: 20),
            Center(
              child: Text(_stage,
                  style: const TextStyle(fontSize: 19),
                  textAlign: TextAlign.center),
            ),
            if (_sampleCount > 0)
              Center(
                child: Text('Samples: $_sampleCount / 10',
                    style: const TextStyle(
                        fontSize: 16, color: Colors.white60)),
              ),
          ] else ...[
            if (_summary.isNotEmpty)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _surfaceLight,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(_summary,
                    style: const TextStyle(
                        fontSize: 19, fontWeight: FontWeight.bold)),
              ),
            const SizedBox(height: 8),
            ..._lines.map(_lineWidget),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: _green,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  textStyle: const TextStyle(
                      fontSize: 19, fontWeight: FontWeight.bold),
                ),
                icon: const Icon(Icons.refresh),
                label: const Text('Dobara Postmortem Karo'),
                onPressed: _run,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'ASAL = phone ke sensor/system se naapi hui cheez. '
              'ANDAZA = asal readings se hisab lagaya hua — ye asal '
              'nap nahi hai. DATA NAHI = is mobile mein ye reading '
              'milti hi nahi, is liye app ne koi tadaad nahi banayi.',
              style: TextStyle(fontSize: 14, color: Colors.white60),
            ),
          ],
        ],
      ),
    );
  }

  Widget _lineWidget(_ReportLine l) {
    final tagColor =
        l.tag == 'ASAL' ? _green : (l.tag == 'ANDAZA' ? _gold : Colors.grey);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(l.title,
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.bold)),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: tagColor,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(l.tag,
                      style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: Colors.black)),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(l.value,
                style: TextStyle(
                    fontSize: 16,
                    color: l.warning ? _red : Colors.white70,
                    fontWeight:
                        l.warning ? FontWeight.bold : FontWeight.normal)),
          ],
        ),
      ),
    );
  }
}
