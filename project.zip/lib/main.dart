// Charge Sach — Battery Doctor (v2 — Underwater Design)
//
// Usool: koi jhoota dawa nahi. Software charger ki taaqat nahi badha
// sakta — ye hardware ki had hai. Ye app do asal kaam karti hai:
//  1. ASAL charging current nap kar dikhati hai (BatteryManager se),
//     taake user ko pata chale charger/cable asal mein kaisa hai.
//  2. Charge ke doran phone ki apni khapat kam karti hai (brightness
//     kam, battery saver ki rehnumai) — khapat kam ho to wohi current
//     battery ko zyada milta hai aur battery jaldi bharti hai.
//  3. BOL KAR batati hai — jaise phone khud baat kar raha ho. Saare
//     jumle asal nap-tol par bante hain.
//  4. Mobile ka POSTMORTEM karti hai — battery, cable, drain aur
//     mobile ki aam sehat ki report, screen par aur bol kar bhi.
//     Jahan data asal hai wahan "ASAL", jahan andaza hai wahan
//     "ANDAZA" saaf likha jata hai.
//  5. V2 DESIGN: photorealistic underwater background, tairti hui
//     asal-numa machhliyan, uthte bulbulay, random waqfe par bari
//     machhli, charger lagne par EK dafa bara charger logo, aur
//     background sound effects (ambient + machhli/bulbulay ki
//     awazein, MediaPlayer se native taraf, TTS ke neeche ducking
//     ke saath). Ye sab Settings ke switches se band ho sakta hai.

import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

const MethodChannel _channel = MethodChannel('com.bozdar.chargesach/battery');

// Underwater palette (v2)
const Color _deepSea = Color(0xFF04182E);
const Color _sea = Color(0xFF0B3D66);
const Color _glass = Color(0xB30A2C4C);
const Color _navBg = Color(0xE6051B33);
const Color _green = Color(0xFF22A565);
const Color _brightGreen = Color(0xFF2ECC71);
const Color _gold = Color(0xFFF2C230);
const Color _red = Color(0xFFEF5350);
const Color _blue = Color(0xFF2196F3);

void main() {
  runApp(const ChargeSachApp());
}

class ChargeSachApp extends StatelessWidget {
  const ChargeSachApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Charge Sach',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: _deepSea,
        colorScheme: const ColorScheme.dark(
          primary: _green,
          secondary: _gold,
          surface: _sea,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        textTheme: const TextTheme(
          bodyLarge: TextStyle(fontSize: 18, color: Colors.white),
          bodyMedium: TextStyle(fontSize: 16, color: Colors.white70),
        ),
      ),
      home: const HomeShell(),
    );
  }
}

/// BatteryManager se aayi hui ek reading. Jo cheez phone nahi deta
/// wo null rehti hai — app wahan "nahi milta" likhti hai.
class BatteryInfo {
  final int? percent;
  final int statusCode; // 2 charging, 3 discharging, 4 not charging, 5 full
  final int? currentMicroA;
  final int? chargeCounterMicroAh;
  final int? voltageMv;
  final int? temperatureTenthsC;
  final int healthCode;
  final String? technology;
  final int pluggedCode; // 0 none, 1 AC, 2 USB, 4 wireless
  final double designCapacityMah;

  const BatteryInfo({
    required this.percent,
    required this.statusCode,
    required this.currentMicroA,
    required this.chargeCounterMicroAh,
    required this.voltageMv,
    required this.temperatureTenthsC,
    required this.healthCode,
    required this.technology,
    required this.pluggedCode,
    required this.designCapacityMah,
  });

  factory BatteryInfo.fromMap(Map<dynamic, dynamic> m) {
    return BatteryInfo(
      percent: m['capacityPercent'] as int?,
      statusCode: (m['statusCode'] as int?) ?? 1,
      currentMicroA: m['currentMicroA'] as int?,
      chargeCounterMicroAh: m['chargeCounterMicroAh'] as int?,
      voltageMv: m['voltageMv'] as int?,
      temperatureTenthsC: m['temperatureTenthsC'] as int?,
      healthCode: (m['healthCode'] as int?) ?? 1,
      technology: m['technology'] as String?,
      pluggedCode: (m['pluggedCode'] as int?) ?? 0,
      designCapacityMah: (m['designCapacityMah'] as num?)?.toDouble() ?? -1,
    );
  }

  bool get plugged => pluggedCode != 0;
  bool get charging => statusCode == 2;
  bool get full => statusCode == 5 || (percent != null && percent! >= 100);

  /// Asal current milli-amp mein. Sign har company ke phone par
  /// mukhtalif hota hai, is liye hamesha asal tadaad (absolute).
  int? get currentMa {
    final c = currentMicroA;
    if (c == null) return null;
    return (c.abs() / 1000).round();
  }

  double? get voltageV =>
      voltageMv == null ? null : voltageMv! / 1000.0;

  double? get temperatureC =>
      temperatureTenthsC == null ? null : temperatureTenthsC! / 10.0;

  double? get chargeCounterMah => chargeCounterMicroAh == null
      ? null
      : chargeCounterMicroAh! / 1000.0;

  String get sourceLabel {
    switch (pluggedCode) {
      case 1:
        return 'AC Charger (bajli wala)';
      case 2:
        return 'USB (computer / power bank)';
      case 4:
        return 'Wireless Charger';
      default:
        return 'Battery par chal raha hai';
    }
  }

  /// Stat card ke liye chhota label.
  String get shortSourceLabel {
    switch (pluggedCode) {
      case 1:
        return 'AC';
      case 2:
        return 'USB';
      case 4:
        return 'Wireless';
      default:
        return 'Battery';
    }
  }

  String get statusLabel {
    if (full) return 'Battery full hai';
    if (charging) return 'Charge ho rahi hai';
    if (plugged) return 'Charger laga hai, charge nahi ho rahi';
    return 'Charge nahi ho rahi';
  }

  String get healthLabel {
    switch (healthCode) {
      case 2:
        return 'Achi hai';
      case 3:
        return 'Battery bohat garam hai';
      case 4:
        return 'Battery kharab (dead) hai';
      case 5:
        return 'Voltage zyada hai';
      case 6:
        return 'Battery fail hai';
      case 7:
        return 'Battery bohat thandi hai';
      default:
        return 'Maloom nahi';
    }
  }

  /// Isi raftar se full honay ka andaza waqt. Asal capacity pehle
  /// design capacity se, warna charge counter se nikalti hai.
  /// Data na mile to null — jhoota andaza nahi lagta.
  Duration? get etaToFull {
    if (!charging) return null;
    final ma = currentMa;
    final pct = percent;
    if (ma == null || ma <= 0 || pct == null || pct >= 100) return null;
    double? fullMah;
    if (designCapacityMah > 0) {
      fullMah = designCapacityMah;
    } else if (chargeCounterMah != null && pct >= 20) {
      fullMah = chargeCounterMah! / (pct / 100.0);
    }
    if (fullMah == null) return null;
    final remainingMah = fullMah * (100 - pct) / 100.0;
    final hours = remainingMah / ma;
    if (hours.isNaN || hours.isInfinite || hours < 0) return null;
    return Duration(minutes: (hours * 60).round());
  }
}

class DeviceInfo {
  final String manufacturer;
  final String model;
  final String androidRelease;
  final int sdkInt;
  final int totalRamBytes;
  final int availRamBytes;
  final int storageTotalBytes;
  final int storageFreeBytes;

  const DeviceInfo({
    required this.manufacturer,
    required this.model,
    required this.androidRelease,
    required this.sdkInt,
    required this.totalRamBytes,
    required this.availRamBytes,
    required this.storageTotalBytes,
    required this.storageFreeBytes,
  });

  factory DeviceInfo.fromMap(Map<dynamic, dynamic> m) {
    return DeviceInfo(
      manufacturer: (m['manufacturer'] as String?) ?? '',
      model: (m['model'] as String?) ?? 'Maloom nahi',
      androidRelease: (m['androidRelease'] as String?) ?? '',
      sdkInt: (m['sdkInt'] as int?) ?? 0,
      totalRamBytes: (m['totalRamBytes'] as int?) ?? 0,
      availRamBytes: (m['availRamBytes'] as int?) ?? 0,
      storageTotalBytes: (m['storageTotalBytes'] as int?) ?? 0,
      storageFreeBytes: (m['storageFreeBytes'] as int?) ?? 0,
    );
  }
}

String _gb(int bytes) =>
    bytes <= 0 ? '—' : (bytes / (1024 * 1024 * 1024)).toStringAsFixed(1);

String _durationText(Duration d) {
  final h = d.inHours;
  final m = d.inMinutes % 60;
  if (h > 0 && m > 0) return '$h ghanta $m minute';
  if (h > 0) return '$h ghanta';
  return '$m minute';
}

/// Charger baghair battery girne ka ek sample (drain check ke liye).
class DrainSample {
  final DateTime time;
  final int percent;
  const DrainSample(this.time, this.percent);
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> with WidgetsBindingObserver {
  BatteryInfo? _info;
  Timer? _timer;
  int _tab = 0;
  int _runToken = 0; // Home se Report ka postmortem chalane ka signal
  bool _resumed = true;

  // --- Bolne wali khidmat ki haalat ---
  bool _speechOn = true;
  String _ttsLanguage = '';
  bool _ttsReady = false;
  int? _lastMilestone; // aakhri elan shuda 10% ka step
  DateTime? _lastSlowWarn;
  bool _low20Spoken = false;
  bool _low10Spoken = false;
  bool _fullSpoken = false;

  // --- Tez Charge Mode ki haalat ---
  bool _tezMode = false;
  int? _savedBrightness;
  bool _savedBrightnessManual = true;
  bool? _powerSave;
  bool? _wifiOn;
  bool? _bluetoothOn;

  // --- V2 design / display settings (pasand save rehti hai) ---
  bool _chargingDisplay = true; // charger lage par screen on + display
  bool _bgAnimation = true; // machhliyan + bulbulay
  bool _sfxSounds = true; // background awazein

  // --- Charger logo: har plug-in par sirf EK dafa ---
  bool _logoVisible = false;
  bool _logoShownThisPlug = false;

  // --- Drain check ka record (charger baghair ke samples) ---
  final List<DrainSample> _drainSamples = [];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _channel.setMethodCallHandler(_nativeCall);
    _initSpeech();
    _initDisplaySettings();
    _refresh();
    _timer = Timer.periodic(const Duration(seconds: 2), (_) => _refresh());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _timer?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _resumed = state == AppLifecycleState.resumed;
    if (_resumed) {
      _applyAmbient();
      _applyScreenOn();
    } else {
      _channel.invokeMethod('stopAmbient').catchError((_) => null);
    }
  }

  Future<void> _initSpeech() async {
    try {
      final on = await _channel.invokeMethod<bool>('getSpeechEnabled');
      final st =
          await _channel.invokeMethod<Map<dynamic, dynamic>>('ttsStatus');
      if (!mounted) return;
      setState(() {
        _speechOn = on ?? true;
        _ttsReady = (st?['ready'] as bool?) ?? false;
        _ttsLanguage = (st?['language'] as String?) ?? '';
      });
    } catch (_) {
      // TTS na ho to khamoshi — app baqi chalti rehti hai.
    }
  }

  Future<void> _initDisplaySettings() async {
    try {
      final s = await _channel
          .invokeMethod<Map<dynamic, dynamic>>('getDisplaySettings');
      if (s != null && mounted) {
        setState(() {
          _chargingDisplay = (s['chargingDisplay'] as bool?) ?? true;
          _bgAnimation = (s['bgAnimation'] as bool?) ?? true;
          _sfxSounds = (s['sfxSounds'] as bool?) ?? true;
        });
      }
    } catch (_) {}
    _applyAmbient();
    _applyScreenOn();
  }

  Future<void> _refresh() async {
    try {
      final m =
          await _channel.invokeMethod<Map<dynamic, dynamic>>('getBatteryInfo');
      if (m == null || !mounted) return;
      final info = BatteryInfo.fromMap(m);
      setState(() => _info = info);
      _trackDrain(info);
      _announce(info);
      _refreshModeStates();
      _applyScreenOn();
    } catch (_) {
      // Reading na mile to purani reading rehne do.
    }
  }

  Future<void> _refreshModeStates() async {
    try {
      final ps = await _channel.invokeMethod<bool>('isPowerSaveMode');
      final radios =
          await _channel.invokeMethod<Map<dynamic, dynamic>>('getRadioStates');
      if (!mounted) return;
      setState(() {
        _powerSave = ps;
        _wifiOn = radios?['wifi'] as bool?;
        _bluetoothOn = radios?['bluetooth'] as bool?;
      });
    } catch (_) {}
  }

  // ---------------- V2: display / awaz ki settings ----------------

  Future<void> _setDisplaySetting(String key, bool value) async {
    setState(() {
      if (key == 'chargingDisplay') _chargingDisplay = value;
      if (key == 'bgAnimation') _bgAnimation = value;
      if (key == 'sfxSounds') _sfxSounds = value;
    });
    try {
      await _channel.invokeMethod(
          'setDisplaySetting', {'key': key, 'value': value});
    } catch (_) {}
    _applyAmbient();
    _applyScreenOn();
  }

  /// Charging Display ON ho aur charger laga ho to screen band nahi
  /// hoti; warna aam phone wala bartao (screen apne waqt par band).
  Future<void> _applyScreenOn() async {
    final on = _chargingDisplay && (_info?.plugged ?? false);
    try {
      await _channel.invokeMethod('setKeepScreenOn', {'enabled': on});
    } catch (_) {}
  }

  /// Ambient underwater awaz sirf tab: Background Animation ON +
  /// Background Awazein ON + app samne ho. Animation band ho to
  /// awazein bhi band (Boz ka hukm).
  Future<void> _applyAmbient() async {
    final on = _bgAnimation && _sfxSounds && _resumed;
    try {
      await _channel.invokeMethod(on ? 'startAmbient' : 'stopAmbient');
    } catch (_) {}
  }

  /// Animation widget ke waqiat (machhli guzri, bari machhli aayi,
  /// bulbulay, nibble) — native MediaPlayer se halki awaz.
  void _onAnimEvent(String name) {
    if (!_bgAnimation || !_sfxSounds || !_resumed) return;
    _channel.invokeMethod('playSfx', {'name': name}).catchError((_) => null);
  }

  // ---------------- Bolne wali khidmat ----------------

  Future<void> _speak(String text, {bool force = false}) async {
    if (!_speechOn && !force) return;
    try {
      await _channel.invokeMethod('speak', {'text': text});
    } catch (_) {}
  }

  Future<void> _setSpeech(bool v) async {
    setState(() => _speechOn = v);
    try {
      await _channel.invokeMethod('setSpeechEnabled', {'enabled': v});
    } catch (_) {}
  }

  /// Native taraf se charger lagne/nikalne ki khabar.
  Future<dynamic> _nativeCall(MethodCall call) async {
    if (call.method != 'onPowerEvent') return null;
    final args = call.arguments as Map<dynamic, dynamic>?;
    final type = args?['type'] as String?;
    final pct = args?['percent'] as int?;
    if (type == 'connected') {
      // Charger logo — is plug-in par sirf EK dafa, 2 second ke liye.
      if (!_logoShownThisPlug && mounted) {
        _logoShownThisPlug = true;
        setState(() => _logoVisible = true);
        Timer(const Duration(milliseconds: 2300), () {
          if (mounted) setState(() => _logoVisible = false);
        });
      }
      // Current ko set honay ka waqt do, phir asal reading bolna.
      await Future<void>.delayed(const Duration(seconds: 3));
      await _refresh();
      final i = _info;
      if (i == null) return null;
      final b = StringBuffer('Charger lag gaya.');
      final v = i.voltageV;
      final ma = i.currentMa;
      if (v != null && ma != null) {
        b.write(
            ' Mujhe ${v.toStringAsFixed(1)} volt aur $ma milliampere current mil raha hai.');
      }
      if (ma != null) {
        if (ma < 500) {
          b.write(
              ' Ye charger sahi nahi hai, dusra charger lagao. Mujhe current pura nahi mil raha.');
        } else if (ma >= 1500) {
          b.write(' Ye charger acha hai.');
        } else {
          b.write(' Charger darmiyana hai, tez nahi hai.');
        }
      }
      // Mukhtasar sehat report: masla ho to charger wali khabar ke
      // saath hi bata do.
      final t = i.temperatureC;
      if (i.healthCode == 4 || i.healthCode == 6) {
        b.write(' Lekin meri battery kharab lagti hai.');
      } else if (t != null && t >= 45) {
        b.write(' Lekin mein bohat garam hoon, mujhe thandi jagah rakho.');
      }
      _speak(b.toString());
    } else if (type == 'disconnected') {
      _logoShownThisPlug = false;
      if (mounted) setState(() => _logoVisible = false);
      final p = pct ?? _info?.percent;
      _speak(p != null
          ? 'Charger nikal gaya. Battery ab $p percent hai.'
          : 'Charger nikal gaya.');
      _applyScreenOn();
    }
    return null;
  }

  /// Har refresh par waqfe wale elan (milestone, slow, low, full).
  void _announce(BatteryInfo i) {
    final pct = i.percent;
    if (pct == null) return;

    if (i.plugged) {
      _low20Spoken = false;
      _low10Spoken = false;

      // Har 10% barhne par elan.
      final milestone = (pct ~/ 10) * 10;
      if (_lastMilestone == null) {
        _lastMilestone = milestone;
      } else {
        if (milestone > _lastMilestone! && pct < 100) {
          _speak('Battery $pct percent ho gayi hai.');
        }
        if (milestone > _lastMilestone!) _lastMilestone = milestone;
      }

      // Slow charge ki darmiyan mein chetaoni (har 15 minute se
      // zyada nahi, taake user tang na ho).
      final ma = i.currentMa;
      if (i.charging && ma != null && ma < 500) {
        final now = DateTime.now();
        if (_lastSlowWarn == null ||
            now.difference(_lastSlowWarn!) >= const Duration(minutes: 15)) {
          _lastSlowWarn = now;
          _speak('Charge bohat slow ho raha hai, mujhe zyada current chahiye.');
        }
      }

      // 100% ka elan — ek dafa.
      if (pct >= 100 && !_fullSpoken) {
        _fullSpoken = true;
        _speak('Mera pait bhar gaya, battery full ho gayi. Charger nikal dein.');
      }
    } else {
      if (pct < 98) _fullSpoken = false;
      _lastMilestone = null;

      if (pct <= 10 && !_low10Spoken) {
        _low10Spoken = true;
        _low20Spoken = true;
        _speak(
            'Bohat zyada bhookh lagi hai, jaldi charger lagao, warna mein band ho jaunga.');
      } else if (pct <= 20 && !_low20Spoken) {
        _low20Spoken = true;
        _speak('Mujhe bhookh lagi hai, charger lagao.');
      }
      if (pct > 25) {
        _low20Spoken = false;
        _low10Spoken = false;
      }
    }
  }

  /// "Abhi sunao" — mojooda haalat foran bol kar sunao. Ye user ka
  /// apna dabana hai, is liye toggle OFF ho tab bhi bolta hai.
  Future<void> _speakNow() async {
    final i = _info;
    if (i == null || i.percent == null) {
      _speak('Abhi battery ki reading nahi mil rahi.', force: true);
      return;
    }
    final b = StringBuffer('Battery ab ${i.percent} percent hai.');
    if (i.plugged) {
      b.write(' Charger laga hai.');
      final ma = i.currentMa;
      if (ma != null) {
        b.write(' Mujhe $ma milliampere current mil raha hai.');
        if (ma < 500) {
          b.write(' Ye charger slow hai.');
        } else if (ma >= 1500) {
          b.write(' Ye charger tez hai.');
        }
      }
      final eta = i.etaToFull;
      if (eta != null) {
        b.write(' Full honay mein taqreeban ${_durationText(eta)} lagein ge.');
      }
    } else {
      b.write(' Charger nahi laga.');
    }
    _speak(b.toString(), force: true);
  }

  // ---------------- Drain record ----------------

  void _trackDrain(BatteryInfo i) {
    if (i.plugged || i.percent == null) return;
    final now = DateTime.now();
    if (_drainSamples.isNotEmpty &&
        now.difference(_drainSamples.last.time) <
            const Duration(minutes: 1)) {
      return;
    }
    _drainSamples.add(DrainSample(now, i.percent!));
    // 2 ghante se purana record saaf kar do.
    _drainSamples.removeWhere(
        (s) => now.difference(s.time) > const Duration(hours: 2));
  }

  // ---------------- Tez Charge Mode ----------------

  Future<void> _tezModeOn() async {
    // Pehle purani brightness yaad rakho, taake wapas ho sake.
    try {
      final b =
          await _channel.invokeMethod<Map<dynamic, dynamic>>('getBrightness');
      _savedBrightness = b?['value'] as int?;
      _savedBrightnessManual = (b?['manual'] as bool?) ?? true;
    } catch (_) {}

    bool ok = false;
    try {
      ok = await _channel.invokeMethod<bool>('canWriteSettings') ?? false;
      if (!ok) {
        // Ijazat ki screen khol do — faisla user ka hai.
        await _channel.invokeMethod('openWriteSettings');
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text(
              'Brightness kam karne ki ijazat dein, phir dobara Tez Charge Mode dabayein.'),
          duration: Duration(seconds: 5),
        ));
        return;
      }
      ok = await _channel.invokeMethod<bool>('setBrightnessMin') ?? false;
    } catch (_) {}
    if (!mounted) return;
    setState(() => _tezMode = ok);
    _refreshModeStates();
  }

  Future<void> _tezModeOff() async {
    try {
      if (_savedBrightness != null) {
        await _channel.invokeMethod('restoreBrightness', {
          'value': _savedBrightness,
          'manual': _savedBrightnessManual,
        });
      }
    } catch (_) {}
    if (!mounted) return;
    setState(() => _tezMode = false);
  }

  // ---------------- UI: shell ----------------

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Underwater background (animation band ho to sada gehra neela)
        Positioned.fill(
          child: UnderwaterBackground(
            animated: _bgAnimation,
            onEvent: _onAnimEvent,
          ),
        ),
        Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            backgroundColor: const Color(0x59041A30),
            leading: const Icon(Icons.menu, color: Colors.white70),
            title: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Charge Sach',
                    style:
                        TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
                Text('Bolti Battery Doctor',
                    style: TextStyle(fontSize: 12.5, color: Colors.white70)),
              ],
            ),
            actions: [
              IconButton(
                icon: Icon(
                  _speechOn ? Icons.volume_up : Icons.volume_off,
                  color: _speechOn ? _brightGreen : Colors.white54,
                ),
                tooltip: 'Awaz on/off',
                onPressed: () => _setSpeech(!_speechOn),
              ),
              IconButton(
                icon: const Icon(Icons.settings, color: Colors.white70),
                tooltip: 'Settings',
                onPressed: () => setState(() => _tab = 3),
              ),
            ],
          ),
          body: IndexedStack(
            index: _tab,
            children: [
              _homePage(),
              PostmortemPage(
                drainSamples: List<DrainSample>.of(_drainSamples),
                speak: (t) => _speak(t),
                speakForce: (t) => _speak(t, force: true),
                active: _tab == 1,
                runToken: _runToken,
              ),
              _tezPage(),
              _settingsPage(),
            ],
          ),
          bottomNavigationBar: BottomNavigationBar(
            type: BottomNavigationBarType.fixed,
            currentIndex: _tab,
            onTap: (t) => setState(() => _tab = t),
            backgroundColor: _navBg,
            selectedItemColor: _brightGreen,
            unselectedItemColor: Colors.white60,
            items: const [
              BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
              BottomNavigationBarItem(
                  icon: Icon(Icons.bar_chart), label: 'Report'),
              BottomNavigationBarItem(
                  icon: Icon(Icons.bolt), label: 'Tez Charge'),
              BottomNavigationBarItem(
                  icon: Icon(Icons.settings), label: 'Settings'),
            ],
          ),
        ),
        // Charger logo — har plug-in par EK dafa, ~2 second
        Positioned.fill(
          child: IgnorePointer(
            child: AnimatedOpacity(
              opacity: _logoVisible ? 1 : 0,
              duration: const Duration(milliseconds: 300),
              child: AnimatedScale(
                scale: _logoVisible ? 1 : 0.5,
                duration: const Duration(milliseconds: 300),
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 150,
                        height: 150,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [Color(0xFF34D399), Color(0xFF0E7A4A)],
                          ),
                          border:
                              Border.all(color: Colors.white70, width: 3),
                          boxShadow: const [
                            BoxShadow(
                                color: Color(0x8034D399),
                                blurRadius: 34,
                                spreadRadius: 6),
                          ],
                        ),
                        child: const Icon(Icons.electric_bolt,
                            size: 84, color: Colors.white),
                      ),
                      const SizedBox(height: 14),
                      const Text('Charger Lag Gaya',
                          style: TextStyle(
                              fontSize: 27,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                              shadows: [
                                Shadow(color: Colors.black87, blurRadius: 10)
                              ])),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ---------------- UI: Home ----------------

  Widget _homePage() {
    final i = _info;
    if (i == null) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(color: _gold),
            SizedBox(height: 16),
            Text('Battery ki reading li ja rahi hai...',
                style: TextStyle(fontSize: 18)),
          ],
        ),
      );
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 20),
      children: [
        _meter(i),
        const SizedBox(height: 6),
        _verdictBanner(i),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.5,
          children: [
            _statCard(
                'Current',
                i.currentMa == null ? 'Nahi milti' : '${i.currentMa} mA',
                Icons.bolt,
                _gold),
            _statCard(
                'Voltage',
                i.voltageV == null
                    ? '—'
                    : '${i.voltageV!.toStringAsFixed(1)} V',
                Icons.electric_bolt,
                _brightGreen),
            _statCard(
                'Temp',
                i.temperatureC == null
                    ? '—'
                    : '${i.temperatureC!.toStringAsFixed(0)} °C',
                Icons.thermostat,
                const Color(0xFFFF7043)),
            _statCard('Power Source', i.shortSourceLabel, Icons.power,
                _brightGreen),
          ],
        ),
        const SizedBox(height: 10),
        _etaCard(i),
        const SizedBox(height: 14),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: _brightGreen,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 15),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30)),
              textStyle:
                  const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            icon: const Icon(Icons.volume_up, size: 26),
            label: const Text('Abhi Sunao'),
            onPressed: _speakNow,
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: _gold,
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(vertical: 15),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30)),
              textStyle:
                  const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            icon: const Icon(Icons.search, size: 24),
            label: const Text('Postmortem Karo'),
            onPressed: () => setState(() {
              _runToken++;
              _tab = 1;
            }),
          ),
        ),
        const SizedBox(height: 14),
        const Text(
          'Note: Koi bhi app charger ki taaqat nahi badha sakti — ye '
          'charger, cable aur phone ke hardware ki had hai. Ye app '
          'asal current dikhati hai aur phone ki khapat kam karke '
          'charge jaldi bharne mein madad karti hai.',
          style: TextStyle(fontSize: 13.5, color: Colors.white60),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  /// Gol meter — beech mein bara percent, gird ghumti hui ring.
  Widget _meter(BatteryInfo i) {
    final pct = i.percent ?? 0;
    final Color ringColor = i.full
        ? _gold
        : (i.plugged ? _brightGreen : (pct <= 20 ? _red : _brightGreen));
    final String status = i.full
        ? 'Full hai'
        : i.charging
            ? 'Charging...'
            : i.plugged
                ? 'Laga hai, charge nahi ho rahi'
                : 'Charger nahi laga';
    return Center(
      child: SizedBox(
        width: 238,
        height: 238,
        child: Stack(
          alignment: Alignment.center,
          children: [
            CustomPaint(
              size: const Size(238, 238),
              painter: _RingPainter(pct.toDouble(), ringColor),
            ),
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  i.full
                      ? Icons.battery_full
                      : (i.charging
                          ? Icons.battery_charging_full
                          : Icons.battery_std),
                  color: ringColor,
                  size: 34,
                ),
                Text(
                  i.percent == null ? '—' : '${i.percent}%',
                  style: const TextStyle(
                      fontSize: 56,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      shadows: [
                        Shadow(color: Colors.black54, blurRadius: 8)
                      ]),
                ),
                Text(status,
                    style: const TextStyle(
                        fontSize: 16.5, color: Colors.white70)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _statCard(String label, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: _glass,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white12),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: color.withOpacity(0.18),
              borderRadius: BorderRadius.circular(11),
            ),
            child: Icon(icon, color: color, size: 25),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: const TextStyle(
                        fontSize: 13.5, color: Colors.white60)),
                Text(value,
                    style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                    overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _etaCard(BatteryInfo i) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: _glass,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white12),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: _brightGreen.withOpacity(0.18),
              borderRadius: BorderRadius.circular(11),
            ),
            child: const Icon(Icons.access_time,
                color: _brightGreen, size: 25),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Estimated Time to Full',
                    style:
                        TextStyle(fontSize: 13.5, color: Colors.white60)),
                Text(
                  i.etaToFull == null
                      ? (i.full ? 'Battery full hai' : 'Andaza nahi lag sakta')
                      : _durationText(i.etaToFull!),
                  style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.white),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _verdictBanner(BatteryInfo i) {
    if (!i.plugged) return const SizedBox.shrink();
    final ma = i.currentMa;
    if (ma == null) {
      return _banner(
          'Charger laga hai — is phone par current ki reading nahi milti, '
          'is liye charger ka faisla nahi ho sakta.',
          _sea);
    }
    if (ma >= 1500) {
      return _banner('Charger tez hai — $ma mA current mil raha hai.', _green);
    }
    if (ma >= 500) {
      return _banner(
          'Charger darmiyana hai — $ma mA current mil raha hai.', _sea);
    }
    return _banner(
        'Charger slow hai — sirf $ma mA mil raha hai. Zyada watt wala '
        'charger lagayein. App charger ki taaqat nahi badha sakti.',
        _red);
  }

  Widget _banner(String text, Color color) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: color.withOpacity(0.85),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(text,
          style: const TextStyle(
              fontSize: 17.5,
              fontWeight: FontWeight.bold,
              color: Colors.white)),
    );
  }

  // ---------------- UI: Tez Charge ----------------

  Widget _tezPage() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
      children: [
        const Text('Tez Charge Mode',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Center(
          child: Container(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white24, width: 2),
              boxShadow: const [
                BoxShadow(color: Colors.black45, blurRadius: 12),
              ],
            ),
            child: const ClipOval(
              child: Image(
                image: AssetImage('assets/images/mascot.jpg'),
                width: 118,
                height: 118,
                fit: BoxFit.cover,
              ),
            ),
          ),
        ),
        const SizedBox(height: 14),
        _checkRow(
          done: _tezMode,
          label: 'Screen Brightness Kam Karein',
          state: _tezMode
              ? 'Ho gaya — roshni sab se kam hai'
              : 'Tez Mode on karne se khud ho jayegi',
        ),
        _checkRow(
          done: _powerSave == true,
          label: 'Battery Saver On Karein',
          state: _powerSave == null
              ? 'Haalat maloom nahi'
              : (_powerSave! ? 'ON hai' : 'OFF hai'),
          buttonText: 'Settings kholo',
          onTap: () => _channel.invokeMethod('openBatterySaverSettings'),
        ),
        _checkRow(
          done: _wifiOn == false && _bluetoothOn == false,
          label: 'Wi-Fi / Bluetooth Band Karein',
          state:
              'Wi-Fi: ${_wifiOn == null ? '?' : (_wifiOn! ? 'ON' : 'OFF')} • '
              'Bluetooth: ${_bluetoothOn == null ? '?' : (_bluetoothOn! ? 'ON' : 'OFF')}',
          buttonText: 'Wi-Fi Settings',
          onTap: () => _channel.invokeMethod('openWifiSettings'),
          button2Text: 'Bluetooth Settings',
          onTap2: () => _channel.invokeMethod('openBluetoothSettings'),
        ),
        const SizedBox(height: 6),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            color: _gold,
            borderRadius: BorderRadius.circular(14),
          ),
          child: const Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(Icons.bolt, color: Colors.black, size: 26),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Ye mode phone ki khapat kam karta hai. Charger ki '
                  'taaqat koi app nahi badha sakti — slow charger ka '
                  'hal zyada watt wala charger hai.',
                  style: TextStyle(
                      fontSize: 15.5,
                      fontWeight: FontWeight.w600,
                      color: Colors.black),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: _tezMode ? _red : _brightGreen,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 15),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30)),
              textStyle:
                  const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            icon: const Icon(Icons.bolt, size: 24),
            label: Text(
                _tezMode ? 'Tez Charge Mode BAND Karein' : 'Tez Charge Mode ON'),
            onPressed: _tezMode ? _tezModeOff : _tezModeOn,
          ),
        ),
        const SizedBox(height: 10),
        const Text(
          'Wi-Fi aur Bluetooth app khud band nahi karti — button se '
          'settings khulti hai, band karna aap ka apna faisla hai.',
          style: TextStyle(fontSize: 13, color: Colors.white54),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _checkRow({
    required bool done,
    required String label,
    required String state,
    String? buttonText,
    VoidCallback? onTap,
    String? button2Text,
    VoidCallback? onTap2,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 5),
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
      decoration: BoxDecoration(
        color: _glass,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                done
                    ? Icons.check_circle
                    : Icons.radio_button_unchecked,
                color: done ? _brightGreen : Colors.white38,
                size: 26,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(label,
                    style: const TextStyle(
                        fontSize: 17.5, fontWeight: FontWeight.w600)),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(left: 36, top: 2),
            child: Text(state,
                style:
                    const TextStyle(fontSize: 14.5, color: Colors.white60)),
          ),
          if (buttonText != null || button2Text != null)
            Padding(
              padding: const EdgeInsets.only(left: 36, top: 6),
              child: Wrap(
                spacing: 8,
                children: [
                  if (buttonText != null)
                    OutlinedButton(
                      onPressed: onTap,
                      child: Text(buttonText),
                    ),
                  if (button2Text != null)
                    OutlinedButton(
                      onPressed: onTap2,
                      child: Text(button2Text),
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  // ---------------- UI: Settings ----------------

  Widget _settingsPage() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
      children: [
        const Text('Settings',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        _switchRow(
          icon: Icons.volume_up,
          iconColor: _brightGreen,
          title: 'Voice Announcements',
          subtitle: _ttsReady
              ? 'Bolne ki suvidha on karein — awaz tayyar hai (${_ttsLanguage.isEmpty ? 'default' : _ttsLanguage})'
              : 'Bolne ki suvidha on karein — awaz tayyar ho rahi hai...',
          value: _speechOn,
          onChanged: _setSpeech,
        ),
        _switchRow(
          icon: Icons.bolt,
          iconColor: _gold,
          title: 'Charging Display',
          subtitle:
              'Charger lage par screen on rahe aur display chalta rahe. Band ho to screen apne waqt par band ho jayegi.',
          value: _chargingDisplay,
          onChanged: (v) => _setDisplaySetting('chargingDisplay', v),
        ),
        _switchRow(
          icon: Icons.waves,
          iconColor: Color(0xFF4FC3F7),
          title: 'Background Animation',
          subtitle:
              'Tairti machhliyan aur uthte bulbulay. Band ho to sada gehra neela background, koi machhli nahi.',
          value: _bgAnimation,
          onChanged: (v) => _setDisplaySetting('bgAnimation', v),
        ),
        _switchRow(
          icon: Icons.music_note,
          iconColor: Color(0xFF81C784),
          title: 'Background Awazein',
          subtitle: _bgAnimation
              ? 'Underwater mahaul ki halki awaz, bulbulay aur machhliyon ki awazein — elan ke waqt khud halki ho jati hain.'
              : 'Background Animation band hai — is liye awazein bhi band hain.',
          value: _sfxSounds,
          enabled: _bgAnimation,
          onChanged: (v) => _setDisplaySetting('sfxSounds', v),
        ),
        _navRow(
          icon: Icons.language,
          iconColor: const Color(0xFF64B5F6),
          title: 'Zabaan / Language',
          subtitle: 'Urdu (Roman Urdu)',
        ),
        _navRow(
          icon: Icons.notifications,
          iconColor: _gold,
          title: 'Alerts',
          subtitle:
              'Battery alerts — kam battery, full aur charger ke elan Voice Announcements se chalte hain.',
        ),
        _navRow(
          icon: Icons.info,
          iconColor: const Color(0xFF64B5F6),
          title: 'App Info',
          subtitle: 'Version 1.1.0',
        ),
        const SizedBox(height: 16),
        GestureDetector(
          onTap: () => setState(() => _tab = 0),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 15),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF8E24AA), Color(0xFF6A1B9A)],
              ),
              borderRadius: BorderRadius.circular(30),
            ),
            child: const Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.home, color: Colors.white, size: 24),
                SizedBox(width: 8),
                Text('Back to Home',
                    style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                        color: Colors.white)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _switchRow({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
    bool enabled = true,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 5),
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 6),
      decoration: BoxDecoration(
        color: _glass,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white12),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.18),
              borderRadius: BorderRadius.circular(11),
            ),
            child: Icon(icon, color: iconColor, size: 24),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 17.5, fontWeight: FontWeight.w600)),
                Text(subtitle,
                    style: const TextStyle(
                        fontSize: 13.5, color: Colors.white60)),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: enabled ? onChanged : null,
            activeColor: _brightGreen,
          ),
        ],
      ),
    );
  }

  Widget _navRow({
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 5),
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
      decoration: BoxDecoration(
        color: _glass,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white12),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.18),
              borderRadius: BorderRadius.circular(11),
            ),
            child: Icon(icon, color: iconColor, size: 24),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 17.5, fontWeight: FontWeight.w600)),
                Text(subtitle,
                    style: const TextStyle(
                        fontSize: 13.5, color: Colors.white60)),
              ],
            ),
          ),
          const Icon(Icons.chevron_right, color: Colors.white38),
        ],
      ),
    );
  }
}

// =====================================================================
// GOL METER KI RING
// =====================================================================

class _RingPainter extends CustomPainter {
  final double pct;
  final Color color;
  const _RingPainter(this.pct, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 12;
    final bgPaint = Paint()
      ..color = Colors.white12
      ..style = PaintingStyle.stroke
      ..strokeWidth = 13;
    canvas.drawCircle(center, radius, bgPaint);
    final sweep = 2 * math.pi * (pct.clamp(0, 100) / 100);
    if (sweep <= 0) return;
    final rect = Rect.fromCircle(center: center, radius: radius);
    final glow = Paint()
      ..color = color.withOpacity(0.25)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 22
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(rect, -math.pi / 2, sweep, false, glow);
    final fg = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 13
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(rect, -math.pi / 2, sweep, false, fg);
  }

  @override
  bool shouldRepaint(_RingPainter old) =>
      old.pct != pct || old.color != color;
}

// =====================================================================
// UNDERWATER BACKGROUND — photorealistic scene par tairti hui
// asal-numa machhliyan (naram kinare wale oval mask mein, taake
// kinare background mein ghul jayein), neeche se uthte bulbulay,
// aur random waqfe (20–45s) par screen paar karti BARI machhli.
// Har harkat ke saath halki awaz ka event (native MediaPlayer ke
// liye) — bubbles / swish / whoosh_big / nibble.
// Animation band ho to sada gehra neela background — koi machhli
// nahi, koi awaz nahi.
// =====================================================================

class _FishCfg {
  final String asset;
  final double width;
  final double yFrac;
  final double period; // screen paar karne ka kul waqt (s)
  final double phase;
  final double bobAmp;
  final double bobSpeed;
  final bool faceRight; // tasveer kis taraf munh kiye hai
  final int dir; // +1 dayein jati hai, -1 bayein
  const _FishCfg(this.asset, this.width, this.yFrac, this.period,
      this.phase, this.bobAmp, this.bobSpeed, this.faceRight, this.dir);
}

class _BubbleCfg {
  final double xFrac;
  final double r;
  final double speed; // px/s
  final double phase;
  final double sway;
  const _BubbleCfg(this.xFrac, this.r, this.speed, this.phase, this.sway);
}

class UnderwaterBackground extends StatefulWidget {
  final bool animated;
  final void Function(String name) onEvent;

  const UnderwaterBackground({
    super.key,
    required this.animated,
    required this.onEvent,
  });

  @override
  State<UnderwaterBackground> createState() => _UnderwaterBackgroundState();
}

class _UnderwaterBackgroundState extends State<UnderwaterBackground>
    with SingleTickerProviderStateMixin {
  Ticker? _ticker;
  double _t = 0; // guzra hua waqt (seconds)
  final math.Random _rand = math.Random();
  late final List<_FishCfg> _fish;
  late final List<_BubbleCfg> _bubbles;
  final List<double> _prevP = [0, 0, 0];

  // Bari machhli ki haalat
  bool _bigActive = false;
  double _bigStart = 0;
  double _bigNext = 14;
  int _bigDir = 1;

  // Awaz ke waqiat ka schedule
  double _nextBubbles = 6;
  double _lastSwish = -10;
  double _nextNibble = 18;
  double _nibbleUntil = -1;

  @override
  void initState() {
    super.initState();
    _fish = const [
      // clown fish — tasveer bayein munh kiye hai, safar dayein
      _FishCfg('assets/images/fish_clown.jpg', 94, 0.30, 34, 0, 10, 0.9,
          false, 1),
      // yellow fish — tasveer dayein munh kiye hai, safar bayein
      _FishCfg('assets/images/fish_yellow.jpg', 74, 0.55, 27, 9, 8, 1.25,
          true, -1),
      // neeli machhli — tasveer bayein munh kiye hai, safar dayein
      _FishCfg('assets/images/fish_blue.jpg', 64, 0.16, 41, 20, 12, 0.7,
          false, 1),
    ];
    _bubbles = List.generate(
      14,
      (i) => _BubbleCfg(
        _rand.nextDouble(),
        2.5 + _rand.nextDouble() * 5.5,
        26 + _rand.nextDouble() * 38,
        _rand.nextDouble(),
        4 + _rand.nextDouble() * 7,
      ),
    );
    _bigNext = 10 + _rand.nextDouble() * 8; // pehli dafa zara jaldi
    if (widget.animated) _startTicker();
  }

  void _startTicker() {
    _ticker = createTicker((elapsed) {
      setState(() {
        _t = elapsed.inMilliseconds / 1000.0;
        _tickEvents();
      });
    });
    _ticker!.start();
  }

  @override
  void didUpdateWidget(UnderwaterBackground old) {
    super.didUpdateWidget(old);
    if (widget.animated && !old.animated) {
      _startTicker();
    } else if (!widget.animated && old.animated) {
      _ticker?.stop();
      _ticker?.dispose();
      _ticker = null;
      _bigActive = false;
    }
  }

  @override
  void dispose() {
    _ticker?.dispose();
    super.dispose();
  }

  double _frac(double x) => x - x.floorToDouble();

  /// Waqt ke saath awaz ke waqiat: bulbulay (har 5–11s), machhli ke
  /// beech se guzarne par swish, nibble ka waqfa, bari machhli ka
  /// random aana (20–45s) aur whoosh.
  void _tickEvents() {
    final t = _t;
    if (t >= _nextBubbles) {
      widget.onEvent('bubbles');
      _nextBubbles = t + 5 + _rand.nextDouble() * 6;
    }
    for (var i = 0; i < _fish.length; i++) {
      final p = _frac((t + _fish[i].phase) / _fish[i].period);
      if (_prevP[i] < 0.5 && p >= 0.5 && t - _lastSwish > 7) {
        _lastSwish = t;
        widget.onEvent('swish');
      }
      _prevP[i] = p;
    }
    if (t >= _nextNibble && _nibbleUntil < 0) {
      _nibbleUntil = t + 3.5;
      widget.onEvent('nibble');
      _nextNibble = t + 18 + _rand.nextDouble() * 20;
    }
    if (_nibbleUntil > 0 && t > _nibbleUntil) _nibbleUntil = -1;
    if (!_bigActive && t >= _bigNext) {
      _bigActive = true;
      _bigStart = t;
      _bigDir = _rand.nextBool() ? 1 : -1;
      widget.onEvent('whoosh_big');
    }
    if (_bigActive && t - _bigStart > 11) {
      _bigActive = false;
      _bigNext = t + 20 + _rand.nextDouble() * 25;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.animated) {
      // Sada gehra neela background — koi machhli, koi harkat nahi.
      return Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF06283D), Color(0xFF03101F)],
          ),
        ),
      );
    }
    return LayoutBuilder(
      builder: (context, c) {
        final w = c.maxWidth;
        final h = c.maxHeight;
        return Stack(
          children: [
            Positioned.fill(
              child: Image.asset('assets/images/underwater_bg.jpg',
                  fit: BoxFit.cover),
            ),
            // Parhne ki asani ke liye halki si gehri parat
            Positioned.fill(
                child: Container(color: const Color(0x59041A30))),
            ..._bubbles.map((b) => _bubbleWidget(b, w, h)),
            ..._fish.asMap().entries.map(
                  (e) => _fishWidget(e.value, w, h,
                      nibbling: e.key == 0 && _nibbleUntil > 0),
                ),
            if (_bigActive) _bigFishWidget(w, h),
          ],
        );
      },
    );
  }

  Widget _bubbleWidget(_BubbleCfg b, double w, double h) {
    final cycle = h + 40;
    final yy = (_t * b.speed + b.phase * cycle) % cycle;
    final top = h - yy - b.r * 2;
    final left = b.xFrac * w + math.sin(_t * 0.9 + b.phase * 9) * b.sway;
    return Positioned(
      left: left,
      top: top,
      child: Container(
        width: b.r * 2,
        height: b.r * 2,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white.withOpacity(0.10),
          border: Border.all(color: Colors.white38, width: 1),
        ),
      ),
    );
  }

  /// Machhli — naram kinare wala oval mask, safar ki simt ke mutabiq
  /// munh, halki si leher (sine bobbing). Nibble ke waqt clown fish
  /// neeche podon ke paas ja kar halki si hilti hai.
  Widget _fishWidget(_FishCfg cfg, double w, double h,
      {bool nibbling = false}) {
    final p = _frac((_t + cfg.phase) / cfg.period);
    final fw = cfg.width;
    final fh = fw * 0.66;
    final double cx =
        cfg.dir == 1 ? -fw / 2 + p * (w + fw) : w + fw / 2 - p * (w + fw);
    double cy =
        cfg.yFrac * h + math.sin(_t * cfg.bobSpeed + cfg.phase) * cfg.bobAmp;
    if (nibbling) {
      cy = 0.80 * h + math.sin(_t * 26) * 3;
    }
    final bool flip = (cfg.dir == 1) != cfg.faceRight;
    return Positioned(
      left: cx - fw / 2,
      top: cy - fh / 2,
      child: Transform(
        transform: Matrix4.diagonal3Values(flip ? -1.0 : 1.0, 1.0, 1.0),
        alignment: Alignment.center,
        child: _softOvalImage(cfg.asset, fw, fh),
      ),
    );
  }

  Widget _bigFishWidget(double w, double h) {
    final p = (_t - _bigStart) / 11;
    const fw = 252.0;
    const fh = fw * 0.66;
    final double cx =
        _bigDir == 1 ? -fw / 2 + p * (w + fw) : w + fw / 2 - p * (w + fw);
    final cy = 0.30 * h + math.sin((_t - _bigStart) * 0.8) * 10;
    // Tasveer dayein munh kiye hai
    final bool flip = _bigDir == -1;
    return Positioned(
      left: cx - fw / 2,
      top: cy - fh / 2,
      child: Transform(
        transform: Matrix4.diagonal3Values(flip ? -1.0 : 1.0, 1.0, 1.0),
        alignment: Alignment.center,
        child: _softOvalImage('assets/images/fish_big.jpg', fw, fh),
      ),
    );
  }

  /// Tasveer ko oval mein kaat kar kinare radial gradient se naram
  /// kar do — kinare asal background mein ghul jate hain.
  Widget _softOvalImage(String asset, double w, double h) {
    return SizedBox(
      width: w,
      height: h,
      child: ShaderMask(
        blendMode: BlendMode.dstIn,
        shaderCallback: (rect) => const RadialGradient(
          radius: 0.9,
          colors: [Colors.white, Colors.white, Colors.transparent],
          stops: [0.0, 0.62, 1.0],
        ).createShader(rect),
        child: ClipOval(
          child: Image.asset(asset, fit: BoxFit.cover, width: w, height: h),
        ),
      ),
    );
  }
}

// =====================================================================
// MOBILE POSTMORTEM — Report tab
// Battery, cable/current, drain aur mobile ki aam sehat ki puri
// report — screen par tafseel aur bol kar khulasa.
// Har line ke saath saaf likha jata hai: ASAL (naapi hui cheez) ya
// ANDAZA (hisab se nikali hui) ya DATA NAHI MILTA. Root ke baghair
// jo cheez naapi nahi ja sakti, us ka dawa nahi hota.
// =====================================================================

class PostmortemPage extends StatefulWidget {
  final List<DrainSample> drainSamples;
  final Future<void> Function(String text) speak;
  final Future<void> Function(String text) speakForce;
  final bool active;
  final int runToken;

  const PostmortemPage({
    super.key,
    required this.drainSamples,
    required this.speak,
    required this.speakForce,
    required this.active,
    required this.runToken,
  });

  @override
  State<PostmortemPage> createState() => _PostmortemPageState();
}

class _ReportLine {
  final String title;
  final String value;
  final String tag; // 'ASAL' | 'ANDAZA' | 'DATA NAHI'
  final IconData icon;
  final bool warning;
  const _ReportLine(this.title, this.value, this.tag, this.icon,
      {this.warning = false});
}

class _PostmortemPageState extends State<PostmortemPage> {
  bool _running = false;
  bool _hasRun = false;
  bool _cancelled = false;
  String _stage = 'Battery ki reading li ja rahi hai...';
  int _sampleCount = 0;
  final List<_ReportLine> _lines = [];
  String _summary = '';

  @override
  void initState() {
    super.initState();
    if (widget.active) _run();
  }

  @override
  void didUpdateWidget(PostmortemPage old) {
    super.didUpdateWidget(old);
    if (widget.runToken != old.runToken) {
      _run();
    } else if (widget.active && !old.active && !_hasRun && !_running) {
      _run();
    }
  }

  @override
  void dispose() {
    _cancelled = true;
    super.dispose();
  }

  Future<BatteryInfo?> _readInfo() async {
    try {
      final m =
          await _channel.invokeMethod<Map<dynamic, dynamic>>('getBatteryInfo');
      return m == null ? null : BatteryInfo.fromMap(m);
    } catch (_) {
      return null;
    }
  }

  Future<void> _run() async {
    if (_running) return;
    _hasRun = true;
    setState(() {
      _running = true;
      _lines.clear();
      _summary = '';
      _sampleCount = 0;
      _stage = 'Battery ki reading li ja rahi hai...';
    });

    final issues = <String>[];
    var batteryGood = false;
    var chargerGood = false;

    final info = await _readInfo();
    if (_cancelled) return;
    if (info == null) {
      setState(() {
        _running = false;
        _stage = 'Battery ki reading nahi mil saki. Dobara koshish karein.';
      });
      return;
    }

    // ---------- 1. Battery sehat (ASAL) ----------
    batteryGood = info.healthCode == 2;
    _lines.add(_ReportLine('Battery Health', info.healthLabel, 'ASAL',
        Icons.favorite,
        warning: !batteryGood && info.healthCode != 1));
    if (info.healthCode == 4 || info.healthCode == 6) {
      issues.add('Battery kharab lagti hai');
    } else if (info.healthCode == 3) {
      issues.add('Battery bohat garam hai');
    } else if (info.healthCode == 5) {
      issues.add('Battery ka voltage zyada hai');
    }

    final t = info.temperatureC;
    if (t == null) {
      _lines.add(const _ReportLine('Temperature',
          'Is mobile mein ye data nahi milta', 'DATA NAHI', Icons.thermostat));
    } else {
      final warn = t >= 40;
      _lines.add(_ReportLine(
        'Temperature',
        '${t.toStringAsFixed(1)} °C${t >= 45 ? ' — bohat garam hai!' : t >= 40 ? ' — garam hai, ehtiyat karein' : ' (Normal)'}',
        'ASAL',
        Icons.thermostat,
        warning: warn,
      ));
      if (t >= 45 && info.healthCode != 3) {
        issues.add('Battery bohat garam hai');
      }
    }

    final v = info.voltageV;
    if (v == null) {
      _lines.add(const _ReportLine('Voltage',
          'Is mobile mein ye data nahi milta', 'DATA NAHI',
          Icons.electric_bolt));
    } else {
      final String halat;
      var warn = false;
      if (v > 4.45) {
        halat = 'Voltage zyada hai';
        warn = true;
      } else if (v < 3.3) {
        halat = 'Voltage kam hai (battery khali honay par aam hai)';
      } else {
        halat = 'Voltage theek hai';
      }
      _lines.add(_ReportLine('Voltage',
          '${v.toStringAsFixed(2)} V — $halat', 'ASAL', Icons.electric_bolt,
          warning: warn));
    }

    // ---------- 2. Battery ki umar / sehat ka ANDAZA ----------
    final counterMah = info.chargeCounterMah;
    final pct = info.percent;
    double? healthPct;
    if (counterMah != null &&
        pct != null &&
        pct >= 20 &&
        info.designCapacityMah > 0) {
      final estFullMah = counterMah / (pct / 100.0);
      healthPct = estFullMah / info.designCapacityMah * 100.0;
      if (healthPct > 100) healthPct = 100;
      final label = healthPct >= 80
          ? 'achi haalat mein hai'
          : healthPct >= 60
              ? 'purani honay lagi hai'
              : 'kamzor ho gayi hai — badalne ka waqt aa raha hai';
      _lines.add(_ReportLine(
        'Health Estimate',
        'Takreeban ${healthPct.toStringAsFixed(0)}% — battery $label '
        '(kul capacity ka andaza ${estFullMah.toStringAsFixed(0)} mAh, '
        'asal design ${info.designCapacityMah.toStringAsFixed(0)} mAh)',
        'ANDAZA',
        Icons.health_and_safety,
        warning: healthPct < 60,
      ));
      if (healthPct < 60) issues.add('Battery kamzor ho gayi hai');
    } else {
      _lines.add(const _ReportLine(
        'Health Estimate',
        'Is mobile mein ye data nahi milta — charge counter ya design '
        'capacity ki reading nahi aayi, is liye andaza nahi lagaya gaya',
        'DATA NAHI',
        Icons.health_and_safety,
      ));
    }

    // ---------- 3. Current stability check (10 second) ----------
    if (info.plugged) {
      setState(() => _stage = 'Current ki checking ho rahi hai — 10 second...');
      final samples = <int>[];
      for (var s = 0; s < 10; s++) {
        await Future<void>.delayed(const Duration(seconds: 1));
        if (_cancelled) return;
        final r = await _readInfo();
        if (_cancelled) return;
        final ma = r?.currentMa;
        if (ma != null) samples.add(ma);
        setState(() => _sampleCount = s + 1);
      }
      final latest = await _readInfo();
      if (_cancelled) return;
      final lastMa = latest?.currentMa ?? info.currentMa;

      if (samples.length < 5) {
        _lines.add(const _ReportLine(
          'Charging Stability',
          'Is mobile mein current ki reading theek se nahi milti — '
          'cable ki checking nahi ho saki',
          'DATA NAHI',
          Icons.cable,
        ));
      } else {
        final avg = samples.reduce((a, b) => a + b) / samples.length;
        final mn = samples.reduce(math.min);
        final mx = samples.reduce(math.max);
        final unstable = mn == 0 ||
            (avg > 0 && mn < 0.35 * avg) ||
            (avg > 0 && (mx - mn) > 0.7 * avg);
        if (unstable) {
          issues.add('Cable ya charging pin mein kharabi lagti hai');
          _lines.add(_ReportLine(
            'Charging Stability',
            'Current bar bar girta/charhta raha (sab se kam $mn mA, '
            'sab se zyada $mx mA, average ${avg.toStringAsFixed(0)} mA). '
            'Cable ya charging pin mein kharabi lagti hai — cable badal '
            'kar dekho, pin saaf karo.',
            'ASAL',
            Icons.cable,
            warning: true,
          ));
        } else {
          _lines.add(_ReportLine(
            'Charging Stability',
            'Current barabar raha (average ${avg.toStringAsFixed(0)} mA, '
            'kam $mn — zyada $mx mA). Cable aur pin theek lagte hain. '
            'Note: kuch phones current ki reading der se badalte hain.',
            'ASAL',
            Icons.cable,
          ));
        }
        if (!unstable && lastMa != null && lastMa >= 500) chargerGood = true;
        if (lastMa != null && lastMa < 500) {
          issues.add('Charger slow hai');
        }
      }
      _lines.add(_ReportLine(
        'Charger Verdict',
        lastMa == null
            ? 'Current ki reading nahi mili'
            : lastMa >= 1500
                ? 'Charger tez hai — $lastMa mA'
                : lastMa >= 500
                    ? 'Charger darmiyana hai — $lastMa mA'
                    : 'Charger slow hai — sirf $lastMa mA. Zyada watt wala charger lagayein.',
        'ASAL',
        Icons.electrical_services,
        warning: lastMa != null && lastMa < 500,
      ));
    } else {
      _lines.add(const _ReportLine(
        'Charging Stability',
        'Charger laga nahi hai — cable ki checking ke liye charger '
        'laga kar postmortem karein',
        'DATA NAHI',
        Icons.cable,
      ));
    }

    // ---------- 4. Battery drain check ----------
    final samplesD = widget.drainSamples;
    if (samplesD.length >= 2) {
      final first = samplesD.first;
      final last = samplesD.last;
      final minutes = last.time.difference(first.time).inMinutes;
      final drop = first.percent - last.percent;
      if (minutes >= 10 && drop > 0) {
        final perHour = drop / (minutes / 60.0);
        final bad = perHour > 10;
        if (bad) {
          issues.add('Battery jaldi gir rahi hai');
        }
        _lines.add(_ReportLine(
          'Drain Rate',
          'Charger baghair $minutes minute mein $drop% battery giri — '
          'raftar takreeban ${perHour.toStringAsFixed(1)}% fi ghanta. '
          '${bad ? 'Ye ghair mamooli hai — battery purani ho gayi hai ya koi app zyada kha raha hai. Battery settings mein dekh kar zyada khane wali app band karein.' : 'Ye raftar aam hai.'}',
          'ANDAZA',
          Icons.show_chart,
          warning: bad,
        ));
      } else {
        _lines.add(_ReportLine(
          'Drain Rate',
          'Abhi sirf $minutes minute ka record hai — drain ka andaza '
          'lagane ke liye app ko charger baghair kam az kam 10 minute '
          'khula rakhein',
          'DATA NAHI',
          Icons.show_chart,
        ));
      }
    } else {
      _lines.add(const _ReportLine(
        'Drain Rate',
        'Abhi record nahi hai — app ko charger baghair kuch der khula '
        'rakhein, phir postmortem karein',
        'DATA NAHI',
        Icons.show_chart,
      ));
    }

    // ---------- 5. Mobile ki aam sehat (ASAL) ----------
    _lines.add(_ReportLine(
      'Battery ki Qisam',
      info.technology ?? 'Maloom nahi',
      info.technology == null ? 'DATA NAHI' : 'ASAL',
      Icons.science,
    ));
    _lines.add(_ReportLine(
      'Abhi Battery mein Charge',
      counterMah == null
          ? 'Is mobile mein ye data nahi milta'
          : '${counterMah.toStringAsFixed(0)} mAh',
      counterMah == null ? 'DATA NAHI' : 'ASAL',
      Icons.battery_std,
    ));
    try {
      final d = await _channel
          .invokeMethod<Map<dynamic, dynamic>>('getDeviceInfo');
      if (_cancelled) return;
      if (d != null) {
        final dev = DeviceInfo.fromMap(d);
        _lines.add(_ReportLine(
          'Device Model',
          '${dev.manufacturer} ${dev.model}',
          'ASAL',
          Icons.phone_android,
        ));
        _lines.add(_ReportLine(
          'Android Version',
          dev.androidRelease,
          'ASAL',
          Icons.android,
        ));
        final usedGb = _gb(dev.storageTotalBytes - dev.storageFreeBytes);
        _lines.add(_ReportLine(
          'Storage',
          '${_gb(dev.storageFreeBytes)} GB khali / kul '
          '${_gb(dev.storageTotalBytes)} GB (bhara hua $usedGb GB)',
          'ASAL',
          Icons.storage,
          warning: dev.storageTotalBytes > 0 &&
              dev.storageFreeBytes / dev.storageTotalBytes < 0.05,
        ));
        _lines.add(_ReportLine(
          'RAM',
          'Kul ${_gb(dev.totalRamBytes)} GB — abhi khali '
          '${_gb(dev.availRamBytes)} GB',
          'ASAL',
          Icons.memory,
        ));
      }
    } catch (_) {
      _lines.add(const _ReportLine('Mobile ki Maloomat',
          'Is mobile mein ye data nahi milta', 'DATA NAHI',
          Icons.phone_android));
    }

    // ---------- Khulasa + bol kar sunao ----------
    final b = StringBuffer('Postmortem mukammal.');
    if (batteryGood) b.write(' Battery ki sehat achi hai.');
    if (chargerGood) b.write(' Charger theek hai.');
    if (issues.isEmpty) {
      b.write(' Mobile ke andar koi kharabi nahi mili.');
    } else {
      b.write(' Ye masle mile: ${issues.toSet().join('. ')}.');
    }
    _summary = b.toString();

    if (!mounted) return;
    setState(() => _running = false);
    widget.speak(_summary);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
      children: [
        const Text('Postmortem Report',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        if (_running) ...[
          const SizedBox(height: 26),
          const Center(child: CircularProgressIndicator(color: _gold)),
          const SizedBox(height: 18),
          Center(
            child: Text(_stage,
                style: const TextStyle(fontSize: 18),
                textAlign: TextAlign.center),
          ),
          if (_sampleCount > 0)
            Center(
              child: Text('Samples: $_sampleCount / 10',
                  style:
                      const TextStyle(fontSize: 15, color: Colors.white60)),
            ),
        ] else if (!_hasRun) ...[
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: _glass,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.white12),
            ),
            child: const Text(
              'Postmortem mein battery ki sehat, charger aur cable ki '
              'checking, battery girne ki raftar aur mobile ki aam '
              'sehat ki puri report banti hai — aur aakhir mein bol '
              'kar bhi sunayi jati hai.',
              style: TextStyle(fontSize: 16.5),
            ),
          ),
          const SizedBox(height: 14),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: _gold,
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(vertical: 15),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30)),
                textStyle: const TextStyle(
                    fontSize: 20, fontWeight: FontWeight.bold),
              ),
              icon: const Icon(Icons.search, size: 24),
              label: const Text('Postmortem Karo'),
              onPressed: _run,
            ),
          ),
        ] else ...[
          ..._lines.map(_lineWidget),
          if (_summary.isNotEmpty) ...[
            const SizedBox(height: 6),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _green.withOpacity(0.30),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _brightGreen.withOpacity(0.5)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.check_circle,
                      color: _brightGreen, size: 28),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(_summary,
                        style: const TextStyle(
                            fontSize: 17.5, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: _blue,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30)),
                textStyle: const TextStyle(
                    fontSize: 19, fontWeight: FontWeight.bold),
              ),
              icon: const Icon(Icons.volume_up, size: 24),
              label: const Text('Report Sunao'),
              onPressed: _summary.isEmpty
                  ? null
                  : () => widget.speakForce(_summary),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 13),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30)),
                textStyle: const TextStyle(
                    fontSize: 18, fontWeight: FontWeight.bold),
              ),
              icon: const Icon(Icons.refresh),
              label: const Text('Dobara Postmortem Karo'),
              onPressed: _run,
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            'ASAL = phone ke sensor/system se naapi hui cheez. '
            'ANDAZA = asal readings se hisab lagaya hua — ye asal '
            'nap nahi hai. DATA NAHI = is mobile mein ye reading '
            'milti hi nahi, is liye app ne koi tadaad nahi banayi.',
            style: TextStyle(fontSize: 13.5, color: Colors.white60),
          ),
        ],
      ],
    );
  }

  Widget _lineWidget(_ReportLine l) {
    final tagColor =
        l.tag == 'ASAL' ? _green : (l.tag == 'ANDAZA' ? _gold : Colors.grey);
    final iconColor = l.warning ? _red : _brightGreen;
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 5),
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
      decoration: BoxDecoration(
        color: _glass,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white12),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.18),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(l.icon, color: iconColor, size: 25),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(l.title,
                          style: const TextStyle(
                              fontSize: 16.5, fontWeight: FontWeight.bold)),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 7, vertical: 2),
                      decoration: BoxDecoration(
                        color: tagColor,
                        borderRadius: BorderRadius.circular(7),
                      ),
                      child: Text(l.tag,
                          style: const TextStyle(
                              fontSize: 10.5,
                              fontWeight: FontWeight.bold,
                              color: Colors.black)),
                    ),
                  ],
                ),
                const SizedBox(height: 3),
                Text(l.value,
                    style: TextStyle(
                        fontSize: 15,
                        color: l.warning ? _red : Colors.white70,
                        fontWeight: l.warning
                            ? FontWeight.bold
                            : FontWeight.normal)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
